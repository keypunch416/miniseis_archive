#!/usr/bin/python
# /amaserver/amahandler.py
# Jon Gilbert
# Last updated: 05/01/2011
# Implements the amaseis server protocol.

# Local imports.
from devices import minisepdevice
from config import miniconfig
from external import lockfile
# Library imports.
import socket
import threading
import SocketServer
from time import gmtime, sleep, time
import os
import sys
import struct
#from obspy.core import UTCDateTime


# Threaded handler for incoming requests.
class AmaHandler(SocketServer.BaseRequestHandler):


    DEBUG = 1
    # Max size of message to read. Derived from AS source.
    MSG_SIZE = 128
    # Sleep time for standard calls.
    STANDARD_DELAY = 0.1
    # Sleep time for FETCHCURRENT calls, stop the client
    # hammering the server with requests.
    FETCH_DELAY = 1
    # The process writing the files buffers its output for 512 samples
    # so only bother looking for new data if this much time has passed.
    # (512/20sps = 25.6)
    FETCH_EXPECTED_UPDATE = 26


    def handle(self):
        keep_alive = True
        self.config = miniconfig.MiniConfig()
        self.amaseis_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.config.get('amaseis_dir'))
        self.last_fetch = 0

        while keep_alive:
            # Block here for data
            try:
                self.data = self.request.recv(128).strip()
            except:
                # Ditch thread on an exception.
                self.__debug('Connection was closed or timed out.')
                return

            # If blank data arrives, close connection.
            if len(self.data) == 0:
                return

            self.__debug('Received: {0}'.format(self.data))

            # Match data at the beginning of each request.
            if self.__strnmatch(self.data, 'PING', 4):
                # Respond with PONG
                self.response = 'PONG'

            elif self.__strnmatch(self.data, 'GETTIME', 7):  
                # Respond with time. 
                # Client expects format "%04d-%02d-%02d %02d:%02d:%02d.%03d"
                t = gmtime()
                form = '{0}:{1}:{2} {3}:{4}:{5}.{6}'
           
                # Pad out values to two characters. Year is always four.
                year = str(t.tm_year)
                month = str(t.tm_mon).zfill(2)
                day = str(t.tm_mday).zfill(2)
                hour = str(t.tm_hour).zfill(2)
                minute = str(t.tm_min).zfill(2)
                second = str(t.tm_sec).zfill(2)
                # Just return zero for ms, data is not _that_ live anyway.
                ms = '000'
                self.response = form.format(year, month, day, hour, minute, 
                        second, ms)

            elif self.__strnmatch(self.data, 'GETSPS', 6):   
                # Respond with sample rate.
                self.response = str(minisepdevice.MiniSepDevice.DEVICE_RATE)

            elif self.__strnmatch(self.data, 'GETLAT', 6):
                # Respond with latitude, as decimal.
                self.response = self.config.get('station_latitude')

            elif self.__strnmatch(self.data, 'GETLONG', 6):            
                # Respond with longitude, as decimal.
                self.response = self.config.get('station_longitude')

            elif self.__strnmatch(self.data, 'GETELE', 6):            
                # Respond with elevation, as decimal.
                self.response = self.config.get('station_elevation')

            elif self.__strnmatch(self.data, 'GETCODE', 7):            
                # Respond with station network code.
                self.response = self.config.get('station_id')  
 
            elif self.__strnmatch(self.data, 'GETNAME', 7):    
                # Respond with station id.
                self.response = self.config.get('station_name')  

            elif self.__strnmatch(self.data, 'GETCOMP', 7):
                # Respond with component. Always 'Z'.
                self.response = self.config.get('component').upper()

            # Note whitespace.
            elif self.__strnmatch(self.data, 'GET ', 4): 
                # Get a named file, return zero if it isn't found.
                self.response = self.__get_file(self.data[4:])

            # Note whitespace.
            elif self.__strnmatch(self.data, 'FETCHCURRENT ', 12):
                # Get the most recent data, starting at the given point.
                self.response = self.__fetchcurrent(self.data[13:])

            elif self.__strnmatch(self.data, 'BYE', 3):
                # Respond with OKAY, end thread after this iteration.
                keep_alive = False
                self.response = 'OKAY'

            else:    
                self.__debug('Unknown request, ignored:' + self.data[:20])
                continue

            # Send response.
            if self.response != None:
                self.request.send(self.response)
                self.__debug('Responded: {0}'.format(self.response[:20]))
            sleep(self.STANDARD_DELAY)
            


    # Print a message to console if enabled.
    def __debug(self, msg):
        if self.DEBUG:
            print(str(msg))

    # Not quite the same as the C function 'strncmp'.
    # Compares up to num characters of the string str1 
    # to those of the string str2. Returns True if they match,
    # False if not.
    def __strnmatch(self, str1, str2, num):
        if str1[:num] == str2[:num]:
            return True
        return False


    # Get a name file, returns content to client, placing 4 bytes at the 
    # front of the data to indicate length. (Required by AmaSeis.)
    # Return 4 bytes at zero as binary if file not available.
    def __get_file(self, name):
        path = self.__amaseis_file_by_name(self.amaseis_dir, name)
        if path == False:
            self.request.send(struct.pack('i', 0))
            self.__debug('Responded: 0')
            try:
                response = self.request.recv(2)
                self.__debug('Received: ' + response)
            except:
                pass
            return None
        else:
            # Lock file.
            try:
                lock = lockfile.FileLock(path)
                lock.acquire(5)
            except lockfile.LockTimeout:
                lock.break_lock()
                lock.acquire()
            except:
                # Break lock this time, return zero and get data on 
                # subsequent calls.
                lock.break_lock()
                self.request.send(struct.pack('i', 0))
                self.__debug('Responded: 0')
                try:
                    response = self.request.recv(2)
                    self.__debug('Received: ' + response)
                except:
                    pass
                return None

            # Read file.
            with open(path, 'rb') as f:
                data = f.read()

            # Release lock, force it if need be.
            if lock.is_locked():
                try:
                    lock.release()
                except:
                    lock.break_lock()

            size = len(data)
            # Send size to client.
            self.request.send(str(size))
            # Wait for an OK. Which client always sends.
            try:
                response = self.request.recv(2)
            except:
                return None
            # Send data to client. Expecting OK or NAK back.
            self.request.send(data)
            self.__debug('Responded: {BINARY DATA}')
            try:
                response = self.request.recv(2)
            except:
                return None
            if response == 'NA':
                try:
                    # Take the last 'K' from buffer on NAK.
                    # The server doesn't seem to need to do anything
                    # with this response thoough.
                    response = response + self.request.recv(1)
                    self.__debug('Received: ' + response)
                except:
                    return None
            else:
                self.__debug('Received: ' + response)
            return None 


    # Get the current data starting at the given point and
    # return content to client, placing 4 bytes at the 
    # front of the data to indicate length. (Required by AmaSeis.)
    # Return 4 bytes at zero if more points beyond 'n' are not available.
    def __fetchcurrent(self, n):
        # Gate fetch by time, return no new data if client is going too fast.
        now = time()
        if  now - self.last_fetch < self.FETCH_DELAY:
            self.request.send('0')
            self.__debug('Responded: 0')
            return None

        # Otherwise update time and check file.
        self.last_fetch = now
        try:
            n = int(n)
        except ValueError:
            self.request.send('0')
            self.__debug('Responded: 0')
            return None  
        
        path = self.__amaseis_file_current(self.amaseis_dir)
        if path == False:
            self.request.send('0')
            self.__debug('Responded: 0')
            return None
        # 2 bytes per sample, check if there are enough for new data.
        elif os.stat(path).st_size <= n * 2:
            self.request.send('0')
            self.__debug('Responded: 0')
        else:
            # Lock file.
            try:
                lock = lockfile.FileLock(path)
                lock.acquire(5)
            except lockfile.LockTimeout:
                lock.break_lock()
                lock.acquire()
            except:
                # Break lock this time, return zero and get data on 
                # subsequent calls.
                lock.break_lock()
                self.request.send('0')
                return None

            # Read file.
            with open(path, 'rb') as f:
                # Skip unwanted data.
                f.seek(n * 2)
                data = f.read()

            # Release lock, force it if need be.
            if lock.is_locked():
                try:
                    lock.release()
                except:
                    lock.break_lock()

            # Send size to client (as number of points at 16 bits each.)
            size = str(len(data) / 2)
            self.__debug('Responded: ' + size)
            self.request.send(size)
            # Wait for OK.
            try:
                response = self.request.recv(2)
                self.__debug('Received: ' + response)
            except:
                pass
            # Send data now.
            self.request.send(data)
            self.__debug('Responded: {BINARY DATA}')
            # Client does not send OK after data, just return.
            return None
            

    # Return the path to a named file, or false if it does not exist.
    def __amaseis_file_by_name(self, amaseis_dir, name):
        # Ensure no paths beginning with '.' or '\', '/'.
        if name[0] == '.' or name[0] == '\\' or name[0] == '/':
            return False
        # Filename is in format YEAR/MONTH/DAY/HOUR.Z
        # but seperator may be windows.
        # Replace '\\' then '\'.
        name = name.replace('\\\\', '/')
        name = name.replace('\\', '/')
        parts = name.split('/')
        if len(parts) != 4:
            return False
        path = amaseis_dir + os.sep + name
        if os.path.isfile(path) == False:
            return False
        return path     


    # Return the path to the current file, or false if it does not exist.
    def __amaseis_file_current(self, amaseis_dir):
        t = gmtime()
        year = str(t.tm_year)
        month = str(t.tm_mon).zfill(2)
        day = str(t.tm_mday).zfill(2)
        hour = str(t.tm_hour).zfill(2)
        local=  year + os.sep + month + os.sep + day + os.sep + hour + '.Z'
        path = amaseis_dir + os.sep + local
        if os.path.isfile(path) == False:
            return False
        return path     


# Wrap threaded API.
class ThreadedAmaServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass
