# sender/minisender.py
# Jon Gilbert
# Updated: 13/01/2011
# Scans through given directory periodically and sends file to 
# specified server via HTTP POST. Sent files are moved to another directory,
# and are then zipped in batches. Failed sends are retried until success.
# If the send operations fail consitently over a long period (as set in 
# FAILURE_TIME_LIMIT) the mode will switch, archiving all files until
# the problem is resolved. These files will not be sent again.

# Local imports.
from config import miniconfig
from tools import miniutil
from debugger import minidebugger
from external.poster import streaminghttp, encode
from external import lockfile
# Library imports.
import os
import shutil
import urllib2
import time
import datetime
import hashlib
import sys
from obspy.mseed.libmseed import LibMSEED
from obspy.core import read, UTCDateTime
import zipfile
import glob


class MiniSender:


    # Define responses expected from server.
    RESPONSE_OK = 'OK'
    RESPONSE_FAIL = 'FAIL'
    # Expected file size (bytes.), actual files can be any multiple of this 
    # value as it represents the miniseed block size.
    FILE_EXPECTED_SIZE = 4096
    # Time between file checks (in seconds.)
    SLEEP_TIME = 30
    # Limit on time (as hours) for constant failures before
    # auto archiving without reattemping to send files.
    FAILURE_TIME_LIMIT = 24
    # Limit on number of files sent per iteration.
    FILE_SEND_LIMIT = 10 
    # Min number of files to appear in the archive dir before zipping them.
    FILE_ARCHIVE_THRESHOLD = 5
    # Max number of files to archive on any iteration.
    FILE_ARCHIVE_LIMIT = 40   
    # File system thresholds (percentages.)
    FS_MIN_SPACE = 10
    FS_TARGET_SPACE = 12


    def __init__(self):
        self.debugger = minidebugger.MiniDebugger('Sender')
        self.debugger.log('Starting Sender...');
        self.utils = miniutil.MiniUtil()
        self.config = miniconfig.MiniConfig()
        self.mseed = LibMSEED() # Used in file validation.
        self.run()


    # Refresh the configuration data.
    def __refresh_config(self):
        self.config.refresh()


    # Main function.
    def run(self):

        print('===================')
        print('Starting MiniSender...')
        print('===================')

        # These items are used to decide when to archive old data.
        now = datetime.datetime.now()
        current_hour = now.hour
        last_send = time.time()
        persistent_fail = False

        # Main loop
        while True:
            # Validate setup. This may change on __refresh_config().
            self.log_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                    + self.config.get('log_dir'))
            self.archive_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                    + self.config.get('archive_dir'))
            self.zip_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                    + self.config.get('zip_dir'))
            self.station_id = self.config.get('station_id')
            self.upload_password = self.config.get('upload_password')
            self.upload_url = self.config.get('upload_url')
            try:
                self.backlog_time = int(self.config.get('backlog_time'))
            except:
                self.backlog_time = 12

            # Check validity of config data.
            # It is possible an uploaded password might not be used 
            # and so it is not checked.
            self.utils.validate_dir(self.log_dir, self.debugger, 
                    'Could not read or create log dir.')
            self.utils.validate_dir(self.archive_dir, self.debugger, 
                    'Could not read or create archive dir.')
            self.utils.validate_dir(self.zip_dir, self.debugger, 
                    'Could not read or create zip dir.')            
            if len(self.station_id) == 0:
                self.debugger.log('Station ID cannot be left blank in config.')
                sys.exit("""Error: Invalid configuration data, exiting. 
                        See log for details.""")
            if len(self.upload_url) == 0:
                self.debugger.log('Upload URL must be set')
                sys.exit("""Error: Invalid configuration data, exitng. 
                        See log for details.""")

            # Limit number of attempts to 3 if in archiving mode.
            if persistent_fail == True:
                send_limit = min(3, self.FILE_SEND_LIMIT)
            else:
                send_limit = self.FILE_SEND_LIMIT

            # Get dir listing and iterate over it, sending files
            # up to the limit value.
            send_count = 0
            fail_count = 0
            counter = 0
            try:
                file_list = os.listdir(self.log_dir)
            except:
                file_list = []
                self.debugger.log('Could not read dir: ' + self.log_dir)
            for fname in file_list:
                fpath = self.log_dir + os.sep + fname
                # Leave the loop if we have reach the send limit.
                # Remaining files will be processed later.
                if counter >= send_limit:
                    break                
                
                # First attempt to lock this file, if successful here
                # the writer has finished with it and we can ignore locks
                # later on when compressing old data.
                # The reason this file is locked is to prevent handling of 
                # any file which the writer has created, but not yet completed.
                try:
                    lock = lockfile.FileLock(fpath)
                    lock.acquire(10)
                except lockfile.LockTimeout:
                    lock.break_lock()
                    lock.acquire()
                except:
                    lock.break_lock()
                    print("Log file locking failed.")
                    self.debugger.log('Log file locking failed.');
                    break
                # Validate and send.
                if os.path.isfile(fpath) and self.validate_file(fpath):
                    self.debugger.log('Sending: ' + fname)
                    result = self.__send_to_server(fpath, fname)
                    if result == True:
                        send_count = send_count + 1
                        to_path = self.archive_dir + os.sep + fname 
                        self.__move_file(fpath, to_path)
                        if persistent_fail == True:
                            self.debugger.log('Sending recommencing.')
                            persistent_fail = False
                        last_send = time.time()
                    # On failure, update counter and check long term failure.
                    else:
                        fail_count = fail_count + 1
                        if persistent_fail == True:
                            self.__compare_file_on_fail(fname, fpath)
                    counter = counter + 1
                # Release lock.
                if lock.is_locked():
                    try:
                        lock.release()
                    except lockfile.NotMyLock, lockfile.NotLocked:
                        pass

            # Log results only if work was done.
            if send_count > 0 or fail_count > 0:
                self.debugger.log('Operation complete: Sent ' + str(send_count)
                        + ', Failed ' + str(fail_count) + '.')

            # Has sending been failing over the long term? Switch modes if so.
            # This flag is reset above on a successful send operation.
            if (fail_count > 0 and persistent_fail == False and 
                    last_send < time.time() - 
                    (60 * 60 * self.FAILURE_TIME_LIMIT)):
                persistent_fail = True
                self.debugger.log('Unable to send, using archive only mode.')

            # Has the archive limit been reached?
            file_count = len([f for f in os.listdir(self.archive_dir) 
                if os.path.isfile(self.archive_dir + os.sep + f)])

            # Compress files if threshold reached.
            if file_count >= self.FILE_ARCHIVE_THRESHOLD:
                self.__manage_free_space()
                self.__compress_old()

            # Sleep for a while, then reload config data.
            time.sleep(self.SLEEP_TIME)
            self.__refresh_config()


    # Takes a file and attempts to send it to the configured page
    # on another server, returns true on success, false otherwise.
    def __send_to_server(self, fpath, fname):
        # get the md5 hash of the file
        fhash = self.md5_for_file(fpath)
        if fhash == False:
            return False
        
        # Get combined hash.
        finalhash = self.md5_file_and_password(fhash, self.upload_password)
        # Attempt to send the file and other parameters to the server.
        streaminghttp.register_openers()
        try:
            params = {'file': open(fpath, 'rb'), 
                    'filename': fname, 
                    'station': self.station_id, 
                    'file_hash': fhash, 
                    'combined_hash': finalhash}
        except IOError:
            return False
       
        try:
            datagen, headers = encode.multipart_encode(params)
            request = urllib2.Request(self.upload_url, datagen, headers)
            # Uses global timeout default.
            result = urllib2.urlopen(request)
        # Note this can raise a httplib.BadStatusLine exception, as well as 
        # urllib2.urlerror. Just catch everything and treat it the same.
        # Expected bug fix for this.
        except:
            return False
        # Expecting: OK or FAIL, anything else is also considered a fail.
        returned = str(result.read())
        if returned == self.RESPONSE_OK:
            return True
        # Must have failed, either explicitly or a timeout.
        self.debugger.log('Server returned: ' + str(returned))
        return False


    # Called when persistent fail flag is set, compares
    # date, time in file to current time and decides whether
    # to move file based on time limit for backlog.
    def __compare_file_on_fail(self, fname, fpath):
        move = False
        # Get date, time from filename.
        # [:-6] remove '.mseed' from name.
        d, t = fname[:-6].split('_')[1:3]
        try:
            # Expected format.
            form = '%Y%m%d %H%M%S'
            ftime = time.mktime(time.strptime(d + ' ' + t, form))
        except:
            # On exception, just the move file anyway. This
            # shouldn't happen as the name was validated
            # earlier, but a race condition could occur in theory.
            move = True
        else:
            offset = 60 * 60 * self.backlog_time
            # Move file if it is old enough.
            if ftime < time.time() - offset or move:
                to_path = self.archive_dir + os.sep + fname
                self.__move_file(fpath, to_path)


    # Move file from log dir to archive dir,
    # this removed it from the pool to be sent on next run.
    def __move_file(self, from_path, to_path):
        try:
            shutil.move(from_path, to_path)
        except IOError:
            self.debugger.log('Tried moving ' + str(from_path) + ' to '
                    + str(to_path) + ' and failed.')
            return False
        return True


    # Checks the free space available for the system and culls old zip archives
    # to free up space if a minimum threshold is met.
    # Scans directory names, searching for smallest, year, month and day.
    def __manage_free_space(self):
        if self.utils.get_free_space() > self.FS_MIN_SPACE:
            return
        current_min = None
        counter = 0
        # The counter prevents an infinite loop if for some reason files
        # being removed does not reduced space by enough. (e.g some other
        # program has filled up the space and can't be dealt with here.) 
        # We may not reach the target value as a result. 
        # File remove exceptions will return this immediately.
        while (counter < 100 and self.utils.get_free_space() 
                < self.FS_TARGET_SPACE):
            try:
                year_list = os.listdir(self.zip_dir)
            except:
                self.debugger.log('Could not read dir: ' + self.zip_dir)
                return
            if not year_list:
                return
            # Scan years first. Remove any empty dirs before sorting the
            # the rest, looking for the oldest.
            years = []
            for y in year_list:
                path = self.zip_dir + os.sep + y
                if not os.listdir(path):
                    try:
                        shutil.rmtree(path)
                    except:
                        self.debugger.log('Could not remove dir: ' + path)
                        return
                else:
                    years.append(y)
            if not years:
                return
            year_dir = self.zip_dir + os.sep + min(years)
            # Now months, again seeking lowest value. Removing empty dirs.
            try:
                month_list = os.listdir(year_dir)
            except:
                self.debugger.log('Could not read dir: ' + self.year_dir)
                return
            months = []
            for m in month_list:
                path = year_dir + os.sep + m
                if not os.listdir(path):
                    try:
                        shutil.rmtree(path)
                    except:
                        self.debugger.log('Could not remove dir: ' + path)
                        return
                else:
                    months.append(m)
            # The last empty month might just have been removed, so skip
            # to the next iteration if needed.
            if not months:
                continue
            month_dir = year_dir + os.sep + min(months)
            try:
                day_list = os.listdir(month_dir)
            except:
                self.debugger.log('Could not read dir: ' + month_dir)
                return
            # Finally days, remove the oldest, regardless of empty status.
            oldest_day = min(day_list)
            path = month_dir + os.sep + oldest_day
            try:
                shutil.rmtree(path)
            except:
                self.debugger.log('Could not remove dir: ' + path)
                return
            counter = counter + 1

        # Write log entry.
        self.debugger.log('Removed old archive files to recover space.')


    # Scan the archived logs and place them in zip files based on their
    # start time. Returns nothing.
    def __compress_old(self):
        # Store list of files in a dictionary, indexed by the 
        # date and hour of their start times.
        # Each list entry is a tuple, (name, path)
        files_to_zip = {} 
        counter = 0
        # Scan archive dir for log files.
        file_list = os.listdir(self.archive_dir)
        for fname in file_list:
            if counter > self.FILE_ARCHIVE_LIMIT:
                break
            fpath = self.archive_dir + os.sep + fname
            # Check its a real log file.
            if self.validate_file(fpath):
                # Read the starttime of the file via obspy.
                stream = read(fpath)
                starttime = stream[0].stats['starttime']
                # Represent this hour uniquely as YEAR_MM_DD_HH
                year = str(starttime.year)
                month = str(starttime.month).zfill(2)
                day = str(starttime.day).zfill(2)
                hour = str(starttime.hour).zfill(2)
                time_key = (year + '_' + month  + '_' + day + '_'  + hour)
                # Add to or create new list.ls
                if files_to_zip.has_key(time_key):
                    files_to_zip[time_key].append((fname, fpath))
                else:
                    files_to_zip[time_key] = [(fname, fpath)]
                counter = counter + 1
        
        # Now create or append the zip files if there were any files found.
        # Remove old log files after they are written to zip.
        if len(files_to_zip) == 0:
            return
        
        for key in files_to_zip:
            zfile = self.__set_zip_dirs(key)
            try:
                f = zipfile.ZipFile(zfile, 'a')
            except:
                self.debugger.log('Could not open archive file correctly - ' 
                        + zfile)
            else:
                for name, path in files_to_zip[key]:
                    f.write(path, name, zipfile.ZIP_DEFLATED)
                    try:
                        os.remove(path)
                    except:
                        self.debugger.log('Could not remove: ' + path)
                f.close()
                # Get file name.
                self.debugger.log('Archive closed - ' + key + '.zip')


    # Takes the name of a zip file, checks for the correct
    # directories, creating them if required then returns the full
    # path for use in writing the file.
    def __set_zip_dirs(self, key):
        items = key.split('_')
        year = items[0]
        month = items[1]
        day = items[2]
        path = self.zip_dir + os.sep + year + os.sep + month + os.sep + day
        if os.path.isdir(path) == False:
            try:
                os.makedirs(path)
            except:
                # If creating dirs fails, exit.
                self.debugger.log('Cannot access zip directory, shutting down.')
                sys.exit(1)
        return path + os.sep + key + '.zip'


    # Takes a path to a file and checks the size to ensure it is
    # a valid log file, returns true if it is, false otherwise.
    # On failure of a file, deletes the file from the directory.
    def validate_file(self, fpath):
        # Basic checks, is this a real file?
        if os.path.isdir(fpath) or os.path.islink(fpath):
            return False
        try:
            f = open(fpath)
            f.close()
        except IOError:
            return False

        # Validate format.
        if self.mseed.isMSEED(fpath) == False:
            try:
                os.remove(fpath)
            except:
                pass       
            return False
        # Validate size. Should be a multiple of block size.
        size = os.path.getsize(fpath)
        if size % self.FILE_EXPECTED_SIZE != 0:
            try:
                os.remove(fpath)
            except:
                pass            
            return False
        # Passed all checks
        return True


    # Returns the md5 hash for a given file
    # modified from:
    # http://stackoverflow.com/questions/3390484
    # Use the hex value for passing over HTTP
    # Returns false on exception.
    def md5_for_file(self, fpath, block_size=128):
        try:
            f = open(fpath, 'rb')
            md5 = hashlib.md5()
            while True:
                data = f.read(block_size)
                if not data:
                    break
                md5.update(data)
        except IOError:
            return False
        return md5.hexdigest()
 

    # Returns h(h(file) + h(password)) to
    # provide integrity and authentication.
    # This cannot say which failed, so send h(file) with the data too.
    def md5_file_and_password(self, fhash, password):
        md5 = hashlib.md5()
        md5.update(password)
        phash = md5.hexdigest()
        combined = fhash + phash
        final = hashlib.md5()
        final.update(combined)
        return final.hexdigest()
