#!/usr/bin/python
# miniamaserver.py
# Jon Gilbert
# Last updated: 30/12/2010
# Starts the amaseis server process.


# Local imports.
from amaserver import amahandler
# Library imports.
import socket
import threading
import SocketServer
import sys


HOST = '0.0.0.0'
PORT = 50000


def main():
    try:
        srv = amahandler.ThreadedAmaServer((HOST, PORT), amahandler.AmaHandler)
        print('=====================')
        ip, port = srv.server_address
        print('Starting MiniAmaSeis Server on {0}:{1}'.format(ip, port))
        print('=====================')        
        server_thread = threading.Thread(target=srv.serve_forever)
        server_thread.start()
        print('Running.')
    except KeyboardInterrupt:
        print('=====================')
        print('Keyboard interrupt received, shutting down server')
        print('=====================')
        server_thread.shutdown()
    except socket.error:
        print('An error occurred:')
        print('Could not bind to port {0}, exiting.'.format(PORT))
        sys.exit(1)
    except:
        print('An unknown error occurred, exiting.')


if __name__ == "__main__":
    __name__ = 'miniamaserver'
    main()
