# /config/miniconfig.py
# Jon Gilbert
# Last updated: 06/01/2011
# Reads/writes to an XML config file and
# will terminate a program if it cannot load config file.
# Uses xml.dom.minidom, which is reportedly slow, however on such a
# small file it doens't really matter.

# Local imports.
from debugger import minidebugger
from external import lockfile
# Library imports.
import os
import sys
import xml.dom.minidom
from urlparse import urlparse
import re
import string


class MiniConfig:


    CONFIG_FILE = 'config/xml/config.xml'
    # These fields names are used to validate the xml file.
    EXPECTED_FIELDS = ['logging_enabled', 'station_id',  
            'station_network', 'component', 'upload_url', 'upload_password', 
            'web_interface_password', 'amaseis_enabled', 'amaseis_port',
            'station_name', 'station_latitude', 'station_longitude', 
            'station_elevation', 'amaseis_dir',  'archive_dir', 'zip_dir', 
            'backlog_time']
    # Values used for type in xml file.
    TYPE_STRING = 'string'
    TYPE_BOOLEAN = 'boolean'


    # Get path of file. set_used determines if a save is needed.
    def __init__(self):
        self.absolute_path = (os.path.dirname(os.path.realpath(sys.argv[0])) +
                os.sep + self.CONFIG_FILE)
        self.debugger = minidebugger.MiniDebugger('Config')
        self.set_used = False
        self.load()


    # Get the contents of the file, or quit on error.
    def load(self):
        self.check_fsize = os.path.getsize(self.absolute_path)
        self.check_fmod = os.path.getmtime(self.absolute_path)
        # First acquire a lock for the file.
        try:
            lock = lockfile.FileLock(self.absolute_path)
            lock.acquire()
        except lockfile.LockError:
            print("Config file locking failed, exiting.")
            self.debugger.log('Config file locking failed');
            sys.exit(1)
        try:
            f = open(self.absolute_path, 'r')
        except IOError:
            # Release lock.
            if lock.is_locked():
                try:
                    lock.release()
                except lockfile.NotMyLock, lockfile.NotLocked:
                    pass
            self.debugger.log('Error: Unable to open config file (' + 
                    self.absolute_path + '), exiting!')
            self.debugger.dump()
            sys.exit(1)
        else:
            try:
                self.dom = xml.dom.minidom.parse(f)
                f.close()
                # Release lock.
                if lock.is_locked():
                    try:
                        lock.release()
                    except lockfile.NotMyLock, lockfile.NotLocked:
                        pass
            except Exception:
                self.debugger.log('Error: Config file could not be parsed (' 
                        + self.absolute_path + '), exiting!')
                self.debugger.dump()
                sys.exit(1)


    # Checks modified time and size of the config file.
    # Calls load() if they differ from last known values.
    def refresh(self):
        if (os.path.getsize(self.absolute_path) != self.check_fsize or 
                os.path.getmtime(self.absolute_path) != self.check_fmod):
            self.load()


	# Returns the value of field attr in the config file
    # or None if it doesn't exist.
    def get(self, attr):
        settings = self.dom.getElementsByTagName('setting')
        for s in settings:
            name = s.getElementsByTagName('name')[0]
            value = s.getElementsByTagName('value')[0]
            if(self.__get_text(name.childNodes) == attr):
                return self.__get_text(value.childNodes)
        return None
 

    # Returns a list of all values relating to 'attr'.
    # Format: [name, prettyname, value, description, type, hidden]
    def get_all(self, attr):
        settings = self.dom.getElementsByTagName('setting')
        for s in settings:
            name = s.getElementsByTagName('name')[0]
            prettyname = s.getElementsByTagName('prettyname')[0]
            value = s.getElementsByTagName('value')[0]
            description = s.getElementsByTagName('description')[0]
            type = s.getElementsByTagName('type')[0]
            hidden = s.getElementsByTagName('hidden')[0]
            if(self.__get_text(name.childNodes) == attr):
                # Construct the list.
                data = [self.__get_text(name.childNodes), 
                        self.__get_text(prettyname.childNodes),
                        self.__get_text(value.childNodes), 
                        self.__get_text(description.childNodes),
                        self.__get_text(type.childNodes),
                        self.__get_text(hidden.childNodes)]
                return data
        return None


    # This version of get accepts another 'dom'
    def get_other_dom(self, attr, dom):
        settings = dom.getElementsByTagName('setting')
        for s in settings:
            name = s.getElementsByTagName('name')[0]
            value = s.getElementsByTagName('value')[0]
            if(self.__get_text(name.childNodes) == attr):
                return self.__get_text(value.childNodes)
        return None


    # Set a value in the dom, return True on 
    # success, False otherwise, call save() afterwards
    # to write the file.
    def set(self, attr, value):
        settings = self.dom.getElementsByTagName('setting')
        for s in settings:
            name = s.getElementsByTagName('name')[0]
            new = old = s.getElementsByTagName('value')[0]
            hidden = s.getElementsByTagName('hidden')[0]
            if(self.__get_text(name.childNodes) == attr):
                # Only update if this item is not hidden.
                if self.__get_text(hidden.childNodes) != 'yes':
                    new.childNodes[0].data = str(value).strip()
                    self.dom.replaceChild(new, old)
                    self.set_used = True
                    return True
        return False


    # Writes current dom to file, if set has been called previously.
    # Returns true on success, false on failure.
    def save(self):
        # Don't both writing if no changes have been made.
        if self.set_used == False:
            return True

        # Get a string from the dom object.
        as_string = self.dom.toxml()

        # Write out, with lock.
        try:
            lock = lockfile.FileLock(self.absolute_path)
            lock.acquire()
        except lockfile.LockError:
            print("Config file locking failed, exiting.")
            self.debugger.log('Config file locking failed');            
            sys.exit(1)

        try:
            f = open(self.absolute_path, 'w')
            f.write(as_string)
            f.close()
        except Exception:
            lock.release()
            self.debugger.log('Unable to write config file.')   
            return False
        self.debugger.log('Saved config file.') 
        # Release lock.
        if lock.is_locked():
            try:
                lock.release()
            except lockfile.NotMyLock, lockfile.NotLocked:
                pass
        return True


    # Extract text data from a list of nodes.
    def __get_text(self, nodelist):
        rc = []
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc.append(node.data)
        return ''.join(rc)


    # Take some given xml data, check it parses correctly.
    # then check it contains the correct data.
    # Returns True on success, False otherwise.
    def validate(self, xml_data):
        # First try to parse.
        try:
            validate_dom = xml.dom.minidom.parseString(xml_data)
        except Exception:
            return False
        else:
            # Now check for fields.
            for field in EXPECTED_FIELDS:
                if self.get_other_dom(field, validate_dom) == None:
                    return False
            # We got this far, so success
            return True
