# /config/miniconfigvalidator.py
# Jon Gilbert
# Last updated: 06/01/2011
# Validates individual config entries.

# Library imports.
import os
import sys
from urlparse import urlparse
import re
import string
from types import StringTypes


# This class holds validation functions for settings.
class MiniConfigValidator:

    
    def __init__(self):
        pass


    # Returns a list, the first value is True/False for success.
    # The second value is a user readable string message (which may be blank) 
    # typically used for explaining errors.
    def validate(self, name, value):
        if (isinstance(name, StringTypes) == False or 
                isinstance(value, StringTypes) == False):
            types = 'Given: ' + str(type(name)) + ', ' + str(type(value))
            result = [False, 'Validator class only accepts strings.' + types]
            return result
        # Call helpers to keep this class more readable.
        if name == 'logging_enabled':
            return self.__logging_enabled(value)
        elif name == 'amaseis_enabled':
            return self.__amaseis_enabled(value)
        elif name == 'amaseis_port':
            return self.__amaseis_port(value)        
        elif name == 'upload_url':
            return self.__upload_url(value)
        elif name == 'upload_password':
            return self.__upload_password(value)  
        elif name == 'web_interface_password':
            return self.__web_interface_password(value)
        elif name == 'log_dir':
            return self.__log_dir(value)
        elif name == 'archive_dir':
            return self.__archive_dir(value) 
        elif name == 'amaseis_dir':
            return self.__amaseis_dir(value)       
        elif name == 'zip_dir':
            return self.__archive_dir(value)   
        elif name == 'station_id':
            return self.__station_id(value)
        elif name == 'station_network':
            return self.__station_network(value)
        elif name == 'station_longitude':
            return self.__station_longitude(value)
        elif name == 'station_latitude':
            return self.__station_latitude(value)
        elif name == 'station_elevation':
            return self.__station_elevation(value) 
        elif name == 'station_name':
            return self.__station_name(value)  
        elif name == 'component':
            return self.__component(value)
        elif name == 'backlog_time':
            return self.__backlog_time(value)
        elif name == 'channel_prefix':
            return self.__channel_prefix(value)           
        else:
            result = [False, 'Unknown field found in config data.']
            return result


    # Helpers below.
    def __logging_enabled(self, value):
        try:
            test = int(value)
        except ValueError, e:
            result = [False, 'Logging enabled must be 1 or 0.']
        else:
            if (test == 0 or test == 1) and str(test) == value:
                result = [True, '']
            else:
                result = [False, 'Logging enabled must be 1 or 0.']
        return result
    

    def __amaseis_enabled(self, value):
        try:
            test = int(value)
        except ValueError, e:
            result = [False, 'AmaSeis enabled must be 1 or 0.']
        else:
            if (test == 0 or test == 1) and str(test) == value:
                result = [True, '']
            else:
                result = [False, 'AmaSeis enabled must be 1 or 0.']
        return result


    def __amaseis_port(self, value):
        try:
            test = int(value)
        except ValueError, e:
            result = [False, 'AmaSeis port must be a number.']
        else:
            if str(test) == value and test >= 50000 and test <= 65535:
                result = [True, '']
            else:
                result = [False, 'AmaSeis port not between 50000 and 65535']
        return result


    def __upload_url(self, value):
        parsed = urlparse(value)
        if parsed.scheme == 'http' and len(parsed.netloc) > 0:
            result = [True, '']
        else:
            result = [False, 'Invalid URL provided, must be http.']
        return result


    def __upload_password(self, value):
        if len(value) > 7:
            result = [True, '']
        else:
            result = [False, """Upload password must be at least 8 
                    characters long."""]
        return result


    def __web_interface_password(self, value):
        if len(value) > 7:
            result = [True, '']
        else:
            result = [False, """Web interface password must be at least 8 
                    characters long."""]
        return result


    # Log directory must exist and be inside the loggers path.
    def __log_dir(self, value):
        path = os.path.dirname(os.path.realpath(sys.argv[0])) + value
        if os.path.isdir(path):
            result = [True, '']
        else:
            result = [False, 'Invalid log directory specified.']
        return result


    # Directory must exist and be inside the loggers path.
    def __archive_dir(self, value):
        path = os.path.dirname(os.path.realpath(sys.argv[0])) + value
        if os.path.isdir(path):
            result = [True, '']
        else:
            result = [False, 'Invalid archive directory specified.']
        return result


    # Directory must exist and be inside the loggers path.
    def __zip_dir(self, value):
        path = os.path.dirname(os.path.realpath(sys.argv[0])) + value
        if os.path.isdir(path):
            result = [True, '']
        else:
            result = [False, 'Invalid zip directory specified.']
        return result


    # Directory must exist and be inside the loggers path.
    def __amaseis_dir(self, value):
        path = os.path.dirname(os.path.realpath(sys.argv[0])) + value
        if os.path.isdir(path):
            result = [True, '']
        else:
            result = [False, 'Invalid amaseis directory specified.']
        return result


    def __station_id(self, value):
        # Check for alphanumeric only.
        pattern = '[\W_]+'
        matches = re.search(pattern, value)
        if matches != None:
            result = [False, 'Station ID must be alphanumeric only.']
        elif len(value) > 5 or len(value) < 3:
            result = [False, """Station ID must be between 3 and 
                    5 characters long."""]
        else:
            result = [True, '']
        return result


    def __station_name(self, value):
        # Amaseis allocates 128 bytes for station name.
        if len(value) > 128:
            result = [False, 'Station name must be less than 128 characters.']
        else:
            result = [True, '']
        return result

    
    # Only Z, N and E are used by the project, but leave other options open.
    # They may be wanted at some later date.
    def __component(self, value):
        # Must be one of a list of values.
        possibles = ['Z', 'N', 'E', 'A', 'B', 'C', 'T', 'R', '1', '2', '3',
                'U', 'V', 'W']
        if value in possibles:
            result = [True, '']
        else:
            result = [False, 'Compenent must be one of Z, N or E.']
        return result


    def __station_network(self, value):
        # Check for alphanumeric only.
        pattern = '[\W_]+'
        matches = re.search(pattern, value)
        if matches != None:
            result = [False, 'Station network must be alphanumeric only.']
        elif len(value) > 3:
            result = [False, """Station network must be between 0 and 
                    3 characters long."""]
        else:
            result = [True, '']
        return result


    def __station_longitude(self, value):
        try:
            test = float(value)
        except ValueError, e:
            result = [False, 'Station longitude must be a decimal value.']  
        else:
            if str(test) == value:
                result = [True, '']
            else:
                result = [False, 'Station longitude must be a decimal value.']
        return result


    def __station_latitude(self, value):
        try:
            test = float(value)
        except ValueError, e:
            result = [False, 'Station latitude must be a decimal value.'] 
        else:
            if str(test) == value:
                result = [True, '']
            else:
                result = [False, 'Station latitude must be a decimal value.']
        return result


    def __station_elevation(self, value):
        try:
            test = float(value)
        except ValueError, e:
            result = [False, 'Station elevation must be a decimal value.'] 
        else:
            # As it may be an int, just check first digit (could be 0.0 == 0.)
            if str(test)[:1] == value[:1]:
                result = [True, '']
            else:
                result = [False, 'Station elevation must be a decimal value.']
        return result


    def __backlog_time(self, value):
        try:
            test = int(value)
        except ValueError, e:
            result = [False, 'Network backlog time must be a number.']
        else:
            if str(test) == value and test >= 500 and test < 0:
                result = [True, '']
            else:
                result = [False, 'Network backlog time must between 0 and 500']
        return result


    def __channel_prefix(self, value):
        # Check for letters only
        if value.is_alpha():
            result = [False, 'Channel prefix must be letters only.']
        elif len(value) > 2:
            result = [False, """Channel must be between 0 and 
                    2 characters long."""]
        else:
            result = [True, '']
        return result  
