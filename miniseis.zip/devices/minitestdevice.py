# device/minisepdevice.py
# Jon Gilbert
# Updated: 18/12/2010
# [For testing] Provides an interface for when a seismometer is not available.

import random

class MiniTestDevice:


    # Device constants.
    DEVICE_RATE = 20 #(Hz)


    def __init__(self, debugger):
        self.ser_device = None
        self.debugger = debugger # inherit loggers debugger.


    # Find a serial or usb connection to the seismometer.
    def find_device(self):
        # Connect, with 1% chance of failure,
        # device will be set to either true or false.
        if random.randint(1, 100) == 50:
            self.ser_device = False
            self.debugger.log('Could not connect to TEST port.');
        else:
            print('Found serial device (Port: TEST)')
            self.ser_device = True

        return self.ser_device


    # Disconnect from any opened ports.
    def disconnect(self):
        self.ser_device = False


    # Fail 0.1% of the time, otherwise generate a random sample value.
    def readline(self):
        if self.ser_device == True:
            # Rough delay to keep sample rate on course,
            # won't be very accurate though!
            delay = 1.0 / self.DEVICE_RATE
            time.sleep(delay)
            if random.randint(1, 1000) == 50:
                return False
            # Return something like a 16 bit int.
            return random.randint(-32000, 32000)
        return False


    # Access to the connections.
    def get_serial_device(self):
        return self.ser_device
