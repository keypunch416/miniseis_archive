# device/minisepdevice.py
# Jon Gilbert
# Updated: 27/01/2011
# Interface for managing SEP seismometer over serial connection.


# Local imports.
from external import serial
# Library imports.
import glob


class MiniSepDevice:


    # Serial configuration
    SER_BAUD = 9600
    SER_PARITY = serial.PARITY_NONE
    SER_PORT = '/dev/ttyUSB0'
    SER_TIMEOUT = 1  
    SER_RTS = 1

    # Device constants.
    DEVICE_RATE = 20 #(Hz)

    # Excluded ports. 
    # If for any reason some port is off limits, place it in this list.
    EXCLUDED_PORTS = ['dev/ttyS0']

    def __init__(self, debugger):
        self.ser_device = None
        self.debugger = debugger # inherit loggers debugger.
    
    
    # Looks for available ports and stores them in a list.
    def __scan_for_ports(self):
        # If the set SER_PORT cannot be used, those found by the code below 
        # will be scanned through in sequence, looking for the right port.
        # Firstly, try Linux /dev/ based port list.
        self.avail_ports = glob.glob('/dev/ttyS*') + glob.glob('/dev/ttyUSB*')
        if len(self.avail_ports) == 0:
            # Fallback, now try all serial ports by number (for Windows)
            # saving any good ones.
            for i in range(256):
                try:
                    s = serial.Serial(i)
                    self.avail_ports.append( (i, s.portstr))
                    s.close()
                except:
                    pass
        # Make sure set port is at front of list, if for some reason it was not
        # found during scan.
        if self.SER_PORT not in self.avail_ports:
            self.avail_ports.insert(0, self.SER_PORT)

        # Finally remove any excluded entries.
        if self.EXCLUDED_PORTS:
            for p in self.EXCLUDED_PORTS:
                if p in self.avail_ports:
                    self.avail_ports.remove(p)


    # Find a serial or serial/usb connection to the seismometer.
    def find_device(self):
        self.__scan_for_ports()
        print('Searching for device...')
        # Check ports one at a time. Will return when the device is found
        # or when all are checked.
        for p in self.avail_ports:
            try:
                print('Trying port: ' + str(p))
                self.debugger.log('Trying port: ' + str(p))
                self.ser_device = serial.Serial(p, self.SER_BAUD, 
                    timeout=self.SER_TIMEOUT, parity=self.SER_PARITY, 
                    rtscts=self.SER_RTS)
            except:
                print('Could not connect to port: ' + p)
                self.debugger.log('Could not connect to port: ' + p)
                self.ser_device = None
            else:
                # If a device was found, try to connect.
                try:
                    self.ser_device.open()
                except serial.SerialException as (strerror):
                    # Try next device
                    print('Serial Error: ' + str(strerror))
                    self.debugger.log('Serial Error: ' + str(strerror))
                    continue
                except:
                    continue
                else:  
                    # Test, take 3 values, if they are all good, return true.
                    passed = False
                    testdata = self.ser_device.readline()
                    if testdata != None:
                        print('Testing serial connection...')
                        self.debugger.log('Testing serial connection...')
                        for i in range(2):
                            passed = True
                            try:
                                data = self.ser_device.readline()
                                data = self.__parse_line(data)
                                data = int(data)
                            except:
                                passed = False
                        # Got some data, connection is good.
                        if passed:
                            print('Serial connection good.')
                            self.debugger.log('Serial connection good.')
                            return True
                        else:
                            print('Serial connection failed.')
                            self.debugger.log ('Serial connection failed.')

        # Final case, all attempts failed.
        return False


    # Disconnect from any opened ports.
    def disconnect(self):
        if self.ser_device != None:
            self.ser_device.close()


    # Returns the next line in the buffer. Timeouts based on settings.
    # On a timeout or no connection present, returns False.
    def readline(self):
        if self.ser_device != None:
            try:
                data = self.ser_device.readline()
            # This is most likely a timeout, but it could be another error.
            except serial.SerialException as (strerror):
                self.debugger.log('Serial Error: ' + str(strerror))
                return False
            except:
                return False
            # Good data, send it back to caller.
            else:
                data = self.__parse_line(data)
                try:
                    data = int(data)
                    return data
                except:
                    return False
        return False


    # Takes a string and removes \r\n chars.
    # For the SEP seismometer.
    def __parse_line(self, data):
        return data.strip();


    # Access to the connections.
    def get_serial_device(self):
        return self.ser_device
