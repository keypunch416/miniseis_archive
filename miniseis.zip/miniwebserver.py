#!/usr/bin/python
# miniwebserver.py
# Jon Gilbert
# Last updated: 30/12/2010
# Starts the webserver. 


# Local imports.
from webserver import miniseishandler
# Library imports.
from BaseHTTPServer import HTTPServer
import os
import socket
import sys


PORT = 80


def main():
    # Start the server.
    try:
        server = HTTPServer(('', PORT), miniseishandler.MiniSeisHandler)
        print('=====================')
        print('Started miniwebserver (port {0})'.format(PORT))
        print('=====================')
        server.serve_forever()
    except KeyboardInterrupt:
        print('=====================')
        print('Keyboard interrupt received, shutting down server now.')
        print('=====================')
        server.socket.close()
    except socket.error:
        print('An error occurred:')
        print('Could not bind to port {0}, exiting.'.format(PORT))
        sys.exit(1)
    #except:
     #   print('An unknown error occurred, exiting.')


if __name__ == '__main__':
    __name__ = 'miniwebserver'
    main()
