# /webserver/miniseishandler.py
# Jon Gilbert
# Last updated: 06/01/2011
# Handles incoming requests and delegates processing to correct class.

#Local imports.
from config import miniconfig
from webserver.pages import (pagetemplate, pagehome, pagestatus, pagelogs, 
    pageconfig, pageconfigsave, pagehelp)
# Library imports.
import string 
import urlparse
import time
import os
from BaseHTTPServer import BaseHTTPRequestHandler
import base64
from shutil import copyfileobj
import sys


class MiniSeisHandler(BaseHTTPRequestHandler):


    config = None
    cache = None
    base_dir = os.path.dirname(os.path.realpath(sys.argv[0]))
    html_dir = base_dir + os.sep + 'webserver' + os.sep + 'html' + os.sep

    BASIC_AUTH_PREFIX = 'Basic '
    AUTH_REQ_STRING = '401 Authentication Required'
    TYPE_HTML = 'text/html'
    TYPE_CSS = 'text/css'


    def setup(self):
        BaseHTTPServer.BaseHTTPRequestHandler.setup(self)
        self.request.settimeout(60)


    def __load_config(self):
        if self.config == None:
            self.config = miniconfig.MiniConfig()


    # When required send authentication challenge.
    def __do_auth(self):
        try:
            self.send_response(401)
            self.send_header('WWW-Authenticate', 
                'Basic realm=\"MiniSeis Administrative Login\"')
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(self.AUTH_REQ_STRING)
        except:
            pass

    # Check if client request has good auth headers.
    def check_auth(self):
        auth = self.headers.getheader('authorization')
        # First look for 'Basic ' at start of string.
        # Remove if found, abort otherwise.
        if auth != None and auth[0:6] == self.BASIC_AUTH_PREFIX:
            encoded = auth[6:len(auth)]
            # Encode expected username and password to base64 for comparison.
            expected = base64.b64encode('admin:' + 
                    self.config.get('web_interface_password'))
            if encoded == expected:
                return True
        self.__do_auth()
        return False

    
    # Takes a string 'content' and pushes it to browser with a 200 status
    # and given type
    def __send_ok_and_page(self, ctype, content):
        try:
            self.send_response(200)
            self.send_header('Content-type', ctype)
            self.end_headers()
            self.wfile.write(content)
        except:
            pass


    # Take a path to a file and send it to the browser.
    # The path should already have been validated.
    def __send_zip_file(self, path):
        try:
            self.send_response(200)
            self.send_header('Content-type', 'application/zip')
            filename = path.split(os.sep).pop()
            self.send_header('Content-Disposition', 'attachment; filename=' 
                + filename)
            self.end_headers()
            with open(path, 'rb') as f:
                copyfileobj(f,self.wfile)
         except:
             pass
        

    # Handles GET requests. Only specified files are allowed, otherwise a 
    # 404 is thrown.
    def do_GET(self):
        self.__load_config()

        # Split off any query string from path.
        bits = self.path.split('?')
        self.path = bits[0]
        if len(bits) > 1:
            self.qs = bits[1]
        else:
            self.qs = None

        # Check the user has valid credentials.
        if self.check_auth() == False:
            return

        # Default/Home page.
        if self.path == '/' or self.path == '/index.html':
            page = pagehome.PageHome(self.html_dir)
            page.generate()
            if page.error == False:
                self.__send_ok_and_page(self.TYPE_HTML, page.content)
            else:
                self.send_error(500,'Internal server error: %s' % self.path)
        
        # View config page. The saveconfig handler is under do_POST.
        elif self.path == '/config.html':
            page = pageconfig.PageConfig(self.html_dir, self.config)
            page.generate()
            if page.error == False:
                self.__send_ok_and_page(self.TYPE_HTML, page.content)
            else:
                self.send_error(500,'Internal server error: %s' % self.path)
    
        # Load static css files.
        elif self.path == '/style.css':
            try:
                f = open(self.html_dir + self.path)
                content = f.read()
            except IOError:
                self.send_error(404,'File Not Found: %s' % self.path)
                return
            self.__send_ok_and_page(self.TYPE_CSS, content)

        # System status page. 
        elif self.path == '/status.html':
            page = pagestatus.PageStatus(self.html_dir, self.base_dir)
            page.generate()
            if page.error == False:
                self.__send_ok_and_page(self.TYPE_HTML, page.content)
            else:
                self.send_error(500,'Internal server error: %s' % self.path)

        # Log download page.
        elif self.path[:10] == '/logs.html':
            if self.qs is not None:
                query = urlparse.parse_qs(self.qs)
            else:
                query = {}
            page = pagelogs.PageLogs(self.html_dir, self.config, self.base_dir,
                    query)
            page.generate()
            if page.error == False:
                self.__send_ok_and_page(self.TYPE_HTML, page.content)
            else:
                self.send_error(500,'Internal server error: %s' % self.path)

        # Download individual file.
        elif self.path[:14] == '/download.html':
            zip_dir = self.base_dir + os.sep + self.config.get('zip_dir')
            if self.qs is not None:
                query = urlparse.parse_qs(self.qs)
                if query.has_key('f'):
                    # Extra path from filename.
                    qry_f = query['f'][0]
                    parts = qry_f.split('_')
                    if len(parts) == 4:
                        y,m,d = parts[:3]
                        path = (zip_dir + os.sep + y + os.sep + m + os.sep 
                                + d + os.sep + qry_f)
                        if os.path.isfile(path) and path.endswith('.zip'):
                            self.__send_zip_file(path)
                            return
                self.send_error(404,'File Not Found: %s' % self.path)
            else:
                self.send_error(404,'File Not Found: %s' % self.path)
        
        # Send favicon
        elif self.path == '/favicon.ico':
            try:
                f = open(self.html_dir + self.path)
                content = f.read()
            except IOError:
                self.send_error(404,'File Not Found: %s' % self.path)
                return
            self.send_response(200)
            self.send_header('Content-type', 'image/x-icon')
            self.end_headers()
            self.wfile.write(content)   

        else:
            #TODO: Provide HTML response with meaningful error
            self.send_error(404,'File Not Found: %s' % self.path)

                 

    # This function looks at the path to determine what action to take.
    # Message contains the response to be sent to the user.
    def do_POST(self):
        self.__load_config()
        # Check the user has valid credentials.
        if self.check_auth() == False:
            self.__do_auth()

        # Config save page.
        if self.path == '/configsave.html':
            # Expects to see data incoming as
            # application/x-www-form-urlencoded.
            form = urlparse.parse_qsl(self.rfile.read(int(
                self.headers.getheader('Content-Length'))))
            page = pageconfigsave.PageConfigSave(self.html_dir, 
                    self.config, form)
            page.generate()            

            if page.error == False:
                self.__send_ok_and_page(self.TYPE_HTML, page.content)
            else:
                self.send_error(500,'Internal server error: %s' % self.path)
            
        else:
            #TODO: Provide HTML response with meaningful error
            self.send_error(404,'File Not Found: %s' % self.path)    
