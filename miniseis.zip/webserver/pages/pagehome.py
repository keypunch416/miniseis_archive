# /webserver/pagehome.py
# Jon Gilbert
# Last updated: 10/12/2010
# Produces output for homepage.

import pagetemplate

class PageHome(pagetemplate.PageTemplate):


    # For now simply read out the html template
    def generate(self):
        try:
            # Get header block.
            f = open(self.html_dir + 'header.html') 
            header_html = f.read()
            f.close()              
            f = open(self.html_dir + 'index.html')
            page = f.read()
            f.close()
        except IOError:
            self.error = True
        self.content = header_html + page
    
    
