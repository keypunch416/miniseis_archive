# /webserver/pagestatus.py
# Jon Gilbert
# Last updated: 10/12/2010
# Show help information.

import pagetemplate

class PageHelp(pagetemplate.PageTemplate):
    

    def generate(self):
        self.content = 'help'
