# /webserver/pagestatus.py
# Jon Gilbert
# Last updated: 10/12/2010
# Produces html view of system log.

# Local imports.
import pagetemplate
# Library imports.
from os import sep
from subprocess import Popen, PIPE


class PageStatus(pagetemplate.PageTemplate):
    

    # Replacement tags found in HTML template
    TAG_LOG = '[tag:log]'
    TAG_NTP = '[tag:ntp]'

    # Accepts the current directory from the server for finding log file.
    def __init__(self, html_dir, curdir):
        self.content = ''
        self.error = False   
        self.html_dir = html_dir
        self.curdir = curdir


    # Reads the log file then displays it for the user.
    def generate(self):
        # Get contents of log file and parse data into skin file.
        try:
            # Log file.
            f = open(self.curdir + sep + 'system_log') 
            log_contents = f.read()
            f.close()
        except IOError:
            self.error = True
            return
        try:
            # Get header block.
            f = open(self.html_dir + 'header.html') 
            header_html = f.read()
            f.close()    
            # Skin file.
            f = open(self.html_dir + 'status.html') 
            page = f.read()
            f.close()
        except IOError:
            self.error = True
            return

        # Place in HTML page.
        page = page.replace(self.TAG_LOG, log_contents)

        # Attempt to get NTP status via ntpq. On failure inform
        # user in a useful way.
        try:
            p = Popen(['ntpq', '-p'], stdout=PIPE)
            ntpq_output = p.stdout.read().strip()
        except:
            ntpq_output = 'Could not determine NTP status at this time.'
        # Place in HTML page.
        page = page.replace(self.TAG_NTP, ntpq_output)

        # Finally combine output
        self.content = header_html + page
