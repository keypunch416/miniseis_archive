# /webserver/pageconfigsave.py
# Jon Gilbert
# Last updated: 18/12/2010
# Takes POSTed data, validates it and saves.
# Each value is saved individually, errors in one item do not
# stop valid values being used.
# The validator class returns meaningful error messages describing what
# each input should be, these strings can be output directly to the user.


# Local imports
import pagetemplate
from config import miniconfigvalidator, miniconfig


class PageConfigSave(pagetemplate.PageTemplate):
   

    # Replacement tags found in HTML template
    TAG_ERRORS = '[tag:errors]'


    # Accepts config object and parsed POST'd form.
    def __init__(self, html_dir, config, form):
        self.content = ''
        self.html_dir = html_dir
        self.error = False   
        self.config = config
        self.form = form


    def generate(self):
        if self.form == None or self.config == None:
            self.error = True
            return

        # Load html files first.
        try:
            # Get header block.
            f = open(self.html_dir + 'header.html') 
            header_html = f.read()
            f.close()            
            # Main skin file.
            f = open(self.html_dir + 'configsave.html') 
            main_html = f.read()
            f.close()
        except IOError:
            self.error = True
            return 

        # Validate each entry. Ignoring non-recognised fields.
        # Save each entry, or record an error when encountered.
        val = miniconfigvalidator.MiniConfigValidator()
        errors = []
        for name, value in self.form:
            if name in miniconfig.MiniConfig.EXPECTED_FIELDS:
                value = value.strip()
                result = val.validate(name, value)
                # Error value?
                if result[0] == False:
                    errors.append(result[1])
                # Otherwise value is good, set it.
                else:
                    test = self.config.set(name, value)

        # Write the config file.
        if self.config.save() == False:
            errors.append('Could not write config file.')

        # Format any errors, splitting each onto a newline.
        if len(errors) > 0:
            errors = ('<br /><br />\n' +
                    'The following errors were found:<br />\n' 
                    + '<br />\n'.join(errors) + '<br /><br />\n' +
                    'These invalid entries have not been saved.')
        else:
            errors = ''

        # Compile output.
        main_html = main_html.replace(self.TAG_ERRORS, errors)
        self.content = header_html + main_html
