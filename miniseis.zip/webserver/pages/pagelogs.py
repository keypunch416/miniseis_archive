# /webserver/pagelogs.py
# Jon Gilbert
# Last updated: 06/01/2011
# Lists available files for download.

# Local imports.
import pagetemplate
# Library imports.
from urlparse import urlparse
import os

class PageLogs(pagetemplate.PageTemplate):


    # Replacement tags found in HTML template
    TAG_YEARS = '[tag:years]'
    TAG_MONTHS = '[tag:months]'
    TAG_DAYS = '[tag:days]'    
    TAG_FILES = '[tag:files]'


    # Accepts config object, program directory and parsed query dictionary.
    def __init__(self, html_dir, config, curdir, query):
        self.content = ''
        self.html_dir = html_dir
        self.error = False   
        self.config = config
        self.query = query
        self.curdir = curdir
     

    def generate(self):
        if self.config == None:
            self.error = True
            return

        # Load html files first.
        try:
            # Get header block.
            f = open(self.html_dir + 'header.html') 
            header_html = f.read()
            f.close()            
            # Main skin file.
            f = open(self.html_dir + 'logs.html') 
            main_html = f.read()
            f.close()
        except IOError:
            self.error = True
            return

        # Set base zip dir.
        self.base = self.curdir + os.sep + self.config.get('zip_dir')
        # Check it exists.
        if os.path.isdir(self.base) == False:
            self.error = False
            return

        # If there is a query it will be in a dict with y,m,d as keys
        # otherwise it is an empty dict.
        # Always get a list of years.
        months = []
        days = [] 
        files = []
        qry_y = qry_m = qry_d = False
        years = self.__get_years()
        if self.query.has_key('y'):
            try: 
                qry_y = int(self.query['y'][0])
            except:
                pass
            else:
                months = self.__get_months(qry_y)

        if self.query.has_key('m') and qry_y != False:
            try: 
                qry_m = int(self.query['m'][0])
            except:
                pass
            else:
                days = self.__get_days(qry_y, qry_m)
             
        if self.query.has_key('d') and qry_m != False:
            try: 
                qry_d = int(self.query['d'][0])
            except:
                pass
            else:
                files = self.__get_files(qry_y, qry_m, qry_d)
    
        # Hold links to for parsing in lists.
        ylinks = []
        mlinks = []
        dlinks = []
        flinks = []

        # Formatting strings.
        y_for = '<a href=\'logs.html?y={0}\'>{0}</a>'
        m_for = '<a href=\'logs.html?y={0}&m={1}\'>{1}</a>'
        d_for = '<a href=\'logs.html?y={0}&m={1}&d={2}\'>{2}</a>'
        f_for = '<a href=\'download.html?f={0}\'>{0}</a>'

        if len(years) > 0:
            for yr in years:
                if yr == str(qry_y):
                    ylinks.append('(' + str(yr) + ')')
                else:
                    ylinks.append(y_for.format(yr))
        else:
            ylinks.append('No log archives currently available.')

        if len(months) > 0:
            for mo in months:
                if mo == str(qry_m).zfill(2):
                    mlinks.append('(' + str(mo) + ')')
                else:
                    mlinks.append(m_for.format(qry_y, mo))
        elif qry_y != False:
            mlinks.append('No data available for this period.')
        else:
            mlinks.append('Select a year to begin.')

        if len(days) > 0:
            for da in days:
                if da == str(qry_d).zfill(2):
                    dlinks.append('(' + str(da) + ')')
                else:
                    dlinks.append(d_for.format(qry_y, qry_m, da))
        elif qry_m != False:
            dlinks.append('No data available for this period.')
        else:
            dlinks.append('Select a month.')

        if len(files) > 0:
            for fi in files:
                flinks.append(f_for.format(fi))
        elif qry_d != False:
            flinks.append('No data available for this period.')
        else:
            flinks.append('Select a day.')

        
        # Compile output. 
        line = '\n'
        main_html = main_html.replace(self.TAG_YEARS, line.join(ylinks)) 
        main_html = main_html.replace(self.TAG_MONTHS, line.join(mlinks)) 
        main_html = main_html.replace(self.TAG_DAYS, line.join(dlinks))
        # For every 2 files, insert a break.
        num = len(flinks) / 2 
        for i in range(1,num+1):
            flinks.insert(((i*3)-1), '<br />')
        main_html = main_html.replace(self.TAG_FILES, line.join(flinks)) 

        self.content = header_html + main_html

    # Get a list of all available years from directories.
    def __get_years(self):
        years = []
        if os.path.isdir(self.base) == False:
            return []
        dr = os.listdir(self.base)
        for name in dr:
            if os.path.isdir(self.base + os.sep + name):
                # Dir names should all be integers.
                try:
                    test = int(name)
                except: 
                    pass
                else:
                    years.append(name)
        # Order them nicely.
        years.sort()
        return years


    # Given a year, list all available months.
    def __get_months(self, year):
        # Years are always 4 digit, no need to pad here.
        path = self.base + os.sep + str(year)
        if os.path.isdir(path) == False:
            return []
        months = []
        dr = os.listdir(path)
        for name in dr:
            if os.path.isdir(path + os.sep + name):
                # Dir names should all be integers.
                try:
                    test = int(name)
                except: 
                    pass
                else:
                    months.append(name)
        # Order them nicely.
        months.sort()
        return months


    # Given a year and a month list all available days.
    def __get_days(self, year, month):
        # Month dirs are two digits, padded with a zero for 1-9.
        m = str(month).zfill(2)
        path = self.base + os.sep + str(year) + os.sep + m
        if os.path.isdir(path) == False:
            return []        
        days = []
        dr = os.listdir(path)
        for name in dr:
            if os.path.isdir(path + os.sep + name):
                # Dir names should all be integers.
                try:
                    test = int(name)
                except: 
                    pass
                else:
                    days.append(name)
        # Order them nicely.
        days.sort()
        return days


    # Given year, month and day, return names of all available files.
    def __get_files(self, year, month, day):
        # Month/day dirs are two digits, padded with a zero for 1-9.
        m = str(month).zfill(2)
        d = str(day).zfill(2)
        path = self.base + os.sep + str(year) + os.sep + m + os.sep + d
        if os.path.isdir(path) == False:
            return []
        files = []
        dr = os.listdir(path)
        for name in dr:
            fpath = path + os.sep + name
            if os.path.isfile(fpath) and name.endswith('.zip'):
                files.append(name)
        # Order them nicely.
        files.sort()
        return files        
