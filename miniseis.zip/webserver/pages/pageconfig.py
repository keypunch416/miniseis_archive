# /webserver/pageconfig.py
# Jon Gilbert
# Last updated: 06/01/2011
# View the current system configuration.

# Local imports.
import pagetemplate


class PageConfig(pagetemplate.PageTemplate):


    # Replacement tags found in HTML template
    TAG_NAME = '[tag:name]'
    TAG_PRETTYNAME = '[tag:prettyname]'
    TAG_DESCRIPTION = '[tag:description]'
    TAG_VALUE = '[tag:value]'
    TAG_ITEMS_LOCATION = '[tag:items_location]'
    TAG_BOOLEAN_ON = '[tag:boolean_on]'
    TAG_BOOLEAN_OFF = '[tag:boolean_off]'

    # We need access to the config data on this page, set it here.
    def __init__(self, html_dir, conf):
        self.content = ''
        self.error = False   
        self.html_dir = html_dir
        self.config = conf

    
    # Generate HTML page or indicate error.
    def generate(self):
        # Check we have config set.
        if self.config == None:
            self.error = True
            return

        # Get config data.
        names = []
        prettynames = []
        values = []
        descriptions = []
        types = []
        hidden = []
        for field in self.config.EXPECTED_FIELDS:
            data = self.config.get_all(field)
            if data == None:
                # Something is wrong with the config data.
                self.error = True
                return
            names.append(data[0])
            prettynames.append(data[1])
            values.append(data[2])
            descriptions.append(data[3])
            types.append(data[4])
            hidden.append(data[5])
        # Template it into skin file.
        try:
            # Get header block.
            f = open(self.html_dir + 'header.html') 
            header_html = f.read()
            f.close()            
            # Main skin file.
            f = open(self.html_dir + 'config.html') 
            main_html = f.read()
            f.close()
            # Segment looped over for each config value.
            f = open(self.html_dir + 'config_item_string.html')
            string_html = f.read()
            f.close()
            f = open(self.html_dir + 'config_item_boolean.html')
            boolean_html = f.read()
            f.close()
        except IOError:
            self.error = True
            return
        
        all_blocks = ''
        # Create the HTML markup for each setting.
        for index, item in enumerate(names):
            # Ignore hidden values.
            if hidden[index] == 'yes':
                continue
            # Select format.
            if types[index] == self.config.TYPE_STRING:
                block = string_html
            else:
                block = boolean_html
            block = block.replace(self.TAG_NAME, item)
            block = block.replace(self.TAG_PRETTYNAME, prettynames[index])
            block = block.replace(self.TAG_DESCRIPTION, descriptions[index])
            block = block.replace(self.TAG_VALUE, values[index])
            # Set the correct value for boolean items.
            if types[index] == self.config.TYPE_BOOLEAN:
                if values[index] == '1':
                    block = block.replace(self.TAG_BOOLEAN_ON, 'checked')
                    block = block.replace(self.TAG_BOOLEAN_OFF, '')
                else: 
                    block = block.replace(self.TAG_BOOLEAN_ON, '')
                    block = block.replace(self.TAG_BOOLEAN_OFF, 'checked')
            all_blocks = all_blocks + block

        # Place within wrapper page.
        self.content = header_html + main_html.replace(self.TAG_ITEMS_LOCATION,
                all_blocks)
