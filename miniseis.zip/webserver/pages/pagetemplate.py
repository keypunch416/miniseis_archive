# /webserver/pagetemplate.py
# Jon Gilbert
# Last updated: 10/12/2010
# Parent class

class PageTemplate():


    content = ''
    error = False


    def __init__(self, html_dir):
        self.content = ''
        self.error = False   
        self.html_dir = html_dir


    def generate(self):
        pass
