# /tools/miniutil.py
# Jon Gilbert
# Last updated: 07/02/2010
# Holds general functions.

# Local imports.
from debugger import minidebugger
# Library imports.
import os
import time
import subprocess
import shlex
import ctypes


class MiniUtil:


    # LED state commands.
    L_HB = 'echo \"heartbeat\" > /sys/class/leds/plug\:green\:health/trigger'
    L_BL = 'echo \"default-on\" > /sys/class/leds/plug\:green\:health/trigger'
    L_GR = 'echo \"green\" > /sys/class/leds/plug\:green\:health/trigger'


    # Validate a directory or try to create it.
    # Takes: path to dir, instance of debugger and an error to
    # throw on failure as a string. Exits program on failure.
    def validate_dir(self, path, debugger, error):
        if os.path.isdir(path) == False:
            try:
                os.mkdir(path)
            except Exception:
                debugger.log(str(error))
                sys.exit("""Error: Invalid configuration data, exiting. 
                        See log for details.""")


    # Turn the led onto flashing blue/green.
    # Note: sheevaplug specific.
    # Does nothing on failure.
    def set_plug_led_heartbeat(self):
        try:
            p = subprocess.Popen(shlex.split(self.L_HB), 
                    stdout=subprocess.PIPE).pid
        except:
            pass


    # Same as above, solid blue led
    def set_plug_led_blue(self):
        try:
            p = subprocess.Popen(shlex.split(self.L_BL), 
                    stdout=subprocess.PIPE).pid
        except:
            pass


    # Same as above, solid green led
    def set_plug_led_green(self):
        try:
            p = subprocess.Popen(shlex.split(self.L_GR), 
                    stdout=subprocess.PIPE).pid
        except:
            pass


    # Return the percentage of free blocks available on the
    # file system. 
    # This uses BAVAIL - "Free blocks available to non-super user."
    # so may return a smaller (free) value than using 'df -k'
    # Modified windows calls from:
    # From: http://code.activestate.com/recipes/511491/
    def get_free_space(self):
        # POSIX version.
        try:
            stats = os.statvfs('/')
            # Calculate free space via (blocks available / total)
            dec = float(stats.f_bavail) / float(stats.f_blocks)
            if dec > 1 or dec < 0:
                return 100
            return int(dec * 100)
        except:
            pass
        # Windows version.
        try:
            GetDiskFreeSpaceEx = ctypes.WINFUNCTYPE(ctypes.c_int, 
                ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64))
            GetDiskFreeSpaceEx = GetDiskFreeSpaceEx(('GetDiskFreeSpaceExW', 
                ctypes.windll.kernel32), ((1, 'lpszPathName'), 
                    (2, 'lpFreeUserSpace'),
                    (2, 'lpTotalSpace'),
                    (2, 'lpFreeSpace'),))

        except AttributeError:
            GetDiskFreeSpaceEx = ctypes.WINFUNCTYPE(ctypes.c_int, 
                ctypes.c_char_p, ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64), 
                ctypes.POINTER(ctypes.c_uint64))
            GetDiskFreeSpaceEx = GetDiskFreeSpaceEx(('GetDiskFreeSpaceExA', 
                ctypes.windll.kernel32), (
                    (1, 'lpszPathName'),
                    (2, 'lpFreeUserSpace'),
                    (2, 'lpTotalSpace'),
                    (2, 'lpFreeSpace'),))

        except:
            # On failure just return 100% free.
            return 100

        free_user, total, free = GetDiskFreeSpaceEx(os.getenv('SystemDrive'))
        # Or extract the data, if it was returned as expected.
        if not total:
            return 100
        # Calculate free space via (lpFreeUserSpace / lpTotalSpace)
        print free_user
        dec = float(free_user) / float(total)
        if dec > 1 or dec < 0:
            return 100    
        return int(dec * 100)
