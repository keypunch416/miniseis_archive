MiniSeis - Data logging and transmission over HTTP of miniseed files.
Copyright (C) 2010-2011  Jon Gilbert

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


==================
Requirements and Dependencies
==================
obspy - http://www.obspy.org/
numpy - http://numpy.scipy.org/ (also required by obspy)

Storage space: At least 2gb.

==================
Startup
==================
Executing the files minilauncher.py, minisender.py, miniwebserver.py 
and miniamaserver.py will start the data logging, transmission, 
web interface and amaseis servers respectively.

It is suggested that you use some form of manager, for example init 
or upstart to start these processes on boot.

==================
Configuration
==================
The file config/xml/config.xml can be (carefully) edited by hand if
required however the web interface provides a form which can be used 
to manage most of the common options. 
The interface can be accessed via a browser and the username is always
'admin'. The default password can be obtained by checking config.xml.
It is highly recommended that you change this password, if lost, it
can be changed or recovered by opening the file again.

==================
Space management
==================
When running the system will automatically attempt to remove old data
if required to free up space for new data. AmaSeis logs will be kept 
for a period of one year, miniseed files will be kept for as long as 
is possible and will begin being removed when free storage drops 
below a cetain threshold.
