#!/usr/bin/python
# /tests/unittests.py
# Jon Gilbert
# Last updated: 04/02/2011
# Executes a test suite. Note this is designed to run on python 2.6
# so TestLoader.discover() is not used.

import unittest
import os
import sys
from test import (test_amaserver, test_config, test_logger, test_debugger, 
        test_util, test_webserver)

def run():
    suite = []
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_amaserver.AmaServerTestCase))
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_config.ConfigTestCase))
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_logger.LoggerTestCase))
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_debugger.DebuggerTestCase))
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_util.UtilTestCase))
    suite.append(unittest.TestLoader().loadTestsFromTestCase(
        test_webserver.WebServerTestCase))

    alltests = unittest.TestSuite(suite)
    
    unittest.TextTestRunner(verbosity=2).run(alltests)
      
if __name__ == '__main__':
    run()

