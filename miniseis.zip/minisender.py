#!/usr/bin/python
# minisender.py
# Jon Gilbert
# Last updated: 21/12/2010
# Starts the sender process. 

# Local imports.
from sender import minisender
# Library imports.
import os


def main():
    minisender.MiniSender()


# Create the sender process.
if __name__ == "__main__":
    __name__ = 'minisender'
    main()
