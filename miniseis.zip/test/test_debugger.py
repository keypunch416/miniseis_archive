#!/usr/bin/python
# /tests/test_debugger.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests debugger (message logging). 

import unittest
from debugger import minidebugger

class DebuggerTestCase(unittest.TestCase):


    def setUp(self):
        self.prefix = 'Test'
        self.debugger = minidebugger.MiniDebugger(self.prefix)
        self.debugger.flush()


    def test_log(self):
        msg = 'Test message'
        self.debugger.log(msg)
        f = open(self.debugger.absolute_path)
        content = f.read()
        expected_end = '[' + self.prefix + '] ' + msg + '\n'
        fail = 'Incorrect log entry'
        self.assertTrue(content.endswith(expected_end), fail)  


    def test_flush(self):
        msg = 'Test message'
        self.debugger.log(msg)
        self.debugger.flush()
        f = open(self.debugger.absolute_path)
        content = f.read()
        fail = 'Log length greater than zero'
        self.assertTrue(len(content) == 0, fail)


    def tearDown(self):
        # Remove any log entries.
        self.debugger.flush()
