#!/usr/bin/python
# /tests/test_buffer.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests for the logger program. Testing of the actually logger/writer should be
# done by generating files and observing feedback. This only tests the 
# buffering mechanisms.

import unittest
from logger import minibuffer
from obspy.core import UTCDateTime


class LoggerTestCase(unittest.TestCase):

    
    def setUp(self):
        pass


    def test_buffer_init(self):
        # Test setup.
        buf = minibuffer.MiniBuffer()
        fail = 'Bad default max size, not default'
        self.assertTrue(buf.get_buffer_max_size() == 
                minibuffer.MiniBuffer.DEFAULT_SIZE, fail)
        # Negative numbers should become absolute values.
        buf = minibuffer.MiniBuffer(-100)
        fail = 'Bad max size'
        self.assertTrue( buf.get_buffer_max_size() == 100, fail)
        # Test other values expected are returned.
        fail = 'Bad starting buffer, not empty'
        self.assertTrue(buf.get_buffer() == [], fail)
        fail = 'Bad filename, not empty'
        self.assertTrue(buf.get_filename() == '', fail)
        fail = 'Bad start time, not zero'
        self.assertTrue(buf.get_start_time() == 0, fail)
        fail = 'Bad end time, not zero'
        self.assertTrue(buf.get_end_time() == 0, fail)
    
    def test_buffer_in_use(self):
        size = 1024
        fn = 'testfile'
        buf = minibuffer.MiniBuffer()
        buf.set_max_size(size)
        buf.set_filename(fn)
        t1 = UTCDateTime()
        buf.set_start_time(t1)
        vals = []
        fail = 'Could not add new value to buffer'
        for i in range(size):
            self.assertTrue(buf.add(i) is True, fail)
            vals.append(i)
        # Should return false now on full.
        fail = 'Buffer full but allowed add()'
        self.assertTrue(not buf.add(i+1), fail)

        t2 = UTCDateTime()
        buf.set_end_time(t2)

        # Test held values.
        fail = 'Start time mismatch'
        self.assertTrue(buf.get_start_time() == t1, fail)
        fail = 'End time mismatch'
        self.assertTrue(buf.get_end_time() == t2, fail)
        fail = 'Filename mismatch'
        self.assertTrue(buf.get_filename() == fn, fail)
        fail = 'Current size mismatch'
        self.assertTrue(buf.get_current_size() == size, fail)
        fail = 'Max size mismatch'
        self.assertTrue(buf.get_buffer_max_size() == size, fail)
        fail = 'Input/get_buffer() mismatch'
        self.assertTrue(buf.get_buffer() == vals, fail)
