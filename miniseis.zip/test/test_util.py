#!/usr/bin/python
# /tests/test_utils.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests shared utils class.

import unittest
from tools import miniutil
from debugger import minidebugger
import shutil
import sys
import os


class UtilTestCase(unittest.TestCase):


    def setUp(self):
        self.utils = miniutil.MiniUtil()


    # This test simply checks no exceptions are uncaught
    # as LEDS may not exist on executing machine.
    def test_leds(self):
        self.utils.set_plug_led_heartbeat()
        self.utils.set_plug_led_blue()
        self.utils.set_plug_led_green()


    def test_validate_dir(self):
        self.test_path = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                    + os.sep + 'dir_for_unit_testing')
        if os.path.isdir(self.test_path):
            shutil.rmtree(self.test_path)

        self.utils.validate_dir(self.test_path, 
                minidebugger.MiniDebugger('Unit Test'), 'Unit test')
        fail = 'Failed to create test directory'
        self.assertTrue(os.path.isdir(self.test_path), fail)
        # Cleanup.
        if os.path.isdir(self.test_path):
            shutil.rmtree(self.test_path)


    # Tests free space check works as expected.
    def test_free_space(self):
        v = self.utils.get_free_space()
        fail = 'Bad value for free space'
        self.assertTrue(v >= 0 and v <= 100, fail)    
