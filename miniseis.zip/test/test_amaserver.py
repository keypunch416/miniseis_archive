#!/usr/bin/python
# /tests/test_webserver.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests AmaSeis server for liveness and attempts to communicate via protocol.

import unittest
import socket
from config import miniconfig
from devices import minisepdevice
import time
import struct 

class AmaServerTestCase(unittest.TestCase):


    def setUp(self):
        self.config = miniconfig.MiniConfig()
        self.amaseis_port = self.config.get('amaseis_port')


    def test_liveness(self):
        host = 'localhost'
        port = int(self.amaseis_port)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.connect((host, port))
            s.shutdown(2)
        except:
            self.fail('Could not connect on port:' + self.amaseis_port)
        

    # Test the amaseis client protocol, setup connections, then request
    # current hour data.
    def test_protocol(self):
        host = 'localhost'
        port = int(self.amaseis_port)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.settimeout(2)
            s.connect((host, port))
        except:
            self.fail('Could not connect on port:' + self.amaseis_port)

        # Handshake.
        s.send('PING')
        data = s.recv(1024)
        fail = 'Sent PING, got ' + data
        self.assertTrue(data == 'PONG', fail)
        s.send('GETTIME')
        data = s.recv(1024)
        fail = 'Sent GETTIME, got nothing'
        self.assertTrue(len(data) > 0, fail) 
        s.send('GETSPS')
        data = s.recv(1024)
        fail = 'Sent GETSPS, got ' + data
        rate = str(minisepdevice.MiniSepDevice.DEVICE_RATE)
        self.assertTrue(data == rate, fail)
        s.send('GETLAT')        
        data = s.recv(1024)
        fail = 'Sent GETLAT, got ' + data
        exp =  self.config.get('station_latitude')
        self.assertTrue(data == exp, fail)
        s.send('GETLONG')        
        data = s.recv(1024)
        fail = 'Sent GETLONG, got ' + data
        exp =  self.config.get('station_longitude')
        self.assertTrue(data == exp, fail)
        s.send('GETELE')        
        data = s.recv(1024)
        fail = 'Sent GETELE, got ' + data
        exp =  self.config.get('station_elevation')
        self.assertTrue(data == exp, fail)
        s.send('GETCODE')        
        data = s.recv(1024)
        fail = 'Sent GETCODE, got ' + data
        exp =  self.config.get('station_id')
        self.assertTrue(data == exp, fail)   
        s.send('GETNAME')        
        data = s.recv(1024)
        fail = 'Sent GETNAME, got ' + data
        exp =  self.config.get('station_name')
        self.assertTrue(data == exp, fail)  
        s.send('GETCOMP')        
        data = s.recv(1024)
        fail = 'Sent GETCOMP, got ' + data
        exp =  self.config.get('component').upper()
        self.assertTrue(data == exp, fail)

        # Test current data fetch
        s.send('FETCHCURRENT 10')        
        data = s.recv(1024)
        fail = 'Sent FETCHCURRENT, got ' + data
        self.assertTrue(len(data) > 0 and int(data) >= 0, fail)
        # If a value > 0 comes back, expecting data for that number of points
        # next, after sending OK back.
        
        if len(data) > 0 and int(data) > 0:
            s.send('OK')        
            while True:
                try:
                    data = data + s.recv(1024).strip()
                except:
                    break
            fail = 'Sent OK, after FETCHCURRENT, got no data back'
            self.assertTrue(len(data) > 0 , fail)     

        # Test file retrieval.
        s.send('GET 2010/12/15/17.Z')
        data = s.recv(1024)
        fail = 'Sent GET 2010/12/15/17.Z, got no data back'
        self.assertTrue(len(data) > 0 and data[0:4] >= 0, fail)   
        if struct.unpack('i', data) > 0:
            s.send('OK')
            while True:
                try:
                    data = data + s.recv(1024)
                except:
                    break
        else:
            self.send('ACK')


        # End connection.
        s.send('BYE')
        try:
            data = s.recv(1024)
        except:
            data = 'nothing'
        fail = 'Sent BYE, got ' + data
        self.assertTrue(data == 'OKAY', fail)

        s.shutdown(2)
        s.close()
