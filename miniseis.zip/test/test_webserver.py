#!/usr/bin/python
# /tests/test_webserver.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests webserver returns the expected response on port 80.

import unittest
from httplib import HTTP
from urlparse import urlparse



class WebServerTestCase(unittest.TestCase):


    def test_liveness(self):
        # Simple check the local port 80 for some running server.
        host = 'http://localhost:80'
        url = urlparse(host)
        request = HTTP(url[1])
        request.putrequest('GET', url[2])
        request.endheaders()
        # Expect auth required response from server.
        fail = 'Could not connect to web server'
        self.assertTrue(request.getreply()[0] == 401, fail)

