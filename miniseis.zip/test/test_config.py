#!/usr/bin/python
# /tests/test_config.py
# Jon Gilbert
# Last updated: 12/02/2011
# Tests for the config, focusing on getting and saving, 
# with validation for sets.

import unittest
from config import miniconfig, miniconfigvalidator
import shutil
import os

class ConfigTestCase(unittest.TestCase):


    def setUp(self):
        self.config = miniconfig.MiniConfig()
        # Make a copy of the config file for testing, 
        # so we don't mess up the original.
        self.test_file = self.config.absolute_path + '.test'
        shutil.copy(self.config.absolute_path, self.test_file)
        self.config.absolute_path = self.test_file
        self.config.load()

    # Load is called by __init__
    def test_load(self):
        try:
            dom = self.config.dom
        except:
            self.fail('Dom not set')
        # Otherwise pass


    def test_refresh(self):
        try:
            dom = self.config.dom
        except:
            self.fail('Dom not set on __init__')
        try:
            # Touch file to force update.
            open(self.config.absolute_path, 'r').close()
            self.config.refresh()
            dom = self.config.dom
        except:
            self.fail('Dom not set on refresh')


    # Tests for a good value, expects None value on non-existent setting.
    def test_get(self):
        good = self.config.get(self.config.EXPECTED_FIELDS[0])
        fail = 'Expected field was not returned'
        self.assertTrue(good is not None, fail)
        bad = self.config.get('A_FAKE_FIELD')    
        fail = 'Fake field still returned a value'
        self.assertTrue(bad is None, fail) 

    
    # Set a value in the dom, then test get() returns it.
    def test_set(self):
        new = 'TestValue'
        orig = self.config.get(self.config.EXPECTED_FIELDS[0])
        self.config.set(self.config.EXPECTED_FIELDS[0], new)
        updated = self.config.get(self.config.EXPECTED_FIELDS[0])
        fail = 'New value did not match after get()'
        self.assertTrue(new == updated, fail)

    # Check (some of) the validator functions.
    def test_validate_good(self):
        val = miniconfigvalidator.MiniConfigValidator()
        res = val.validate('logging_enabled', '0')
        fail = 'Logged enabled = 0, failed'
        self.assertTrue(res[0], fail)
        res = val.validate('logging_enabled', '1')
        fail = 'Logged enabled = 1, failed'        
        self.assertTrue(res[0], fail)
        res = val.validate('station_id', 'ABC')
        fail = 'Station id = ABC, failed'        
        self.assertTrue(res[0], fail)
        res = val.validate('station_name', 'Test Station')
        fail = 'Station name = Test Station, failed'        
        self.assertTrue(res[0], fail)


    def test_validate_bad(self):
        val = miniconfigvalidator.MiniConfigValidator()
        res = val.validate('logging_enabled', '24')
        fail = 'Logged enabled = 24, failed'
        self.assertFalse(res[0], fail)        
        res = val.validate('logging_enabled', 'test')
        fail = 'Logged enabled = test, failed'
        self.assertFalse(res[0], fail)  
        res = val.validate('station_network', '??//')
        fail = 'Station network = ??//, failed'
        self.assertFalse(res[0], fail)  
        res = val.validate('non_existent_field', 'test')
        fail = 'Bad field name = test, failed'
        self.assertFalse(res[0], fail)  


    def test_save(self):
        original = self.config.get('station_network')
        new = original + 'unittestdata'
        self.config.set('station_network', new)
        res = self.config.save()
        fail = 'Save() returned false'
        self.assertTrue(res, fail)   
        # Load config from scratch.
        self.config = miniconfig.MiniConfig()
        self.config.absolute_path = self.test_file
        self.config.load()
        got = self.config.get('station_network')
        fail = 'Save failed, get() returned: ' + got
        self.assertTrue(got == new, fail)    
        self.config.set('station_network', original)
        self.config.save()


    def tearDown(self):
        # Delete test file after use.
        os.remove(self.test_file)
