# minidebugger.py
# Jon Gilbert
# Last updated: 18/12/2010
# Writes status messages to a log file, trims the log randomly.
# Called 'debugger' to avoid confusion with main logger.

# Library imports.
from time import gmtime, strftime
import os
import random
import sys


class MiniDebugger:
    

    LOG_FILE = '/system_log'
    # The number of entries to try and limit the log file to.
    TRIM_LEVEL = 100


    def __init__(self, name):
        self.absolute_path = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.LOG_FILE)
        # Prefix identifies who sent the message.
        self.prefix = '[' + str(name) + '] '


    # Write message to log file.
    def log(self, message):
        self.__keep_log_short()
        try:
            f = open(self.absolute_path, 'a')
        except IOError:
            # Couldn't get file.
            return
        else:
            timestamp = strftime("%d/%m/%y %H:%M:%S UTC", gmtime())
            message = timestamp + ' - ' + self.prefix + message + '\n'
            f.write(message)
            f.close()
    

    # Dump contents of log file to console.
    def dump(self):
        try:
            f = open(self.absolute_path, 'r')
        except IOError:
            # Couldn't get file. Do nothing.
            return
        print('================')
        print('Dumping:' + self.LOG_FILE)
        print('================')
        for line in f:
            # Strip to 
            print(line.strip())


    # Opening in 'w' mode should truncate the file.
    def flush(self):
        try:
            f = open(self.absolute_path, 'w')
            f.close()
        except IOError:
            # Couldn't get file. Do nothing.
            pass
  

    # Removes excessive lines to reduce space usage.
    # Chance of executing on any call is 1%.
    def __keep_log_short(self):
        if random.randrange(1, 100) != 50:
            return
        # Get lines in file.
        try:
            f = open(self.absolute_path, 'r')
            log = f.readlines()
            f.close()
        except IOError:
            return
        count = len(log)
        # If the line count if more than TRIM_LEVEL, 
        # remove enough to bring it down to TRIM_LEVEL / 2.
        if count < self.TRIM_LEVEL:
            return
        to_remove = count - self.TRIM_LEVEL / 2
        del log[0:to_remove]
        # Write the remaining lines back to the log file after flushing it.
        f = open(self.absolute_path, 'w')
        f.writelines(log)
        f.close()
