#!/usr/bin/python
# minilogger.py
# Jon Gilbert
# Last updated: 21/12/2010
# Main program, spawns the two processes for buffering data
# and writing the results files.


# Local imports.
from logger import minilogger, miniwriter
# Library imports.
from multiprocessing import Process, Queue
import sys
import os


def main():
    # Create the queue with fixed maxsize, if the logger is creating buffers 
    # faster than the writer can send them to file something is wrong.
    q = Queue(2000)
    # Start the processes and join them.
    logger = Process(target=minilogger.MiniLogger, args=(q,))
    writer = Process(target=miniwriter.MiniWriter, args=(q,))
    logger.start()
    writer.start()
    logger.join()
    writer.join()


# Create the two processes.
if __name__ == "__main__":
    __name__ = 'minilogger'
    main()
