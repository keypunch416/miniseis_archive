# logger/minilogger.py
# Jon Gilbert
# Last updated: 27/01/2011
# Reads from the seismometer and puts time-stamped data into a queue
# which is read from by miniwriter.

# Local imports.
from config import miniconfig
from debugger import minidebugger
from tools import miniutil
from devices import minisepdevice
import minibuffer
# Library imports.
from obspy.core import UTCDateTime
from multiprocessing import Queue
import time
import datetime
import os
import sys
import atexit


class MiniLogger:


    INTERRUPT_VALUE = 'INTR'
    # Set this to stop attempts to disable the LEDs on the sheevaplug,
    # this might be needed on other platforms, but hopefully the code
    # used will handle all exceptions and ignore failure.
    DISABLE_LEDS = False


    # Start logger.
    def __init__(self, q):
        atexit.register(self.__cleanup)

        # Setup and enter run().
        self.q = q
        self.debugger = minidebugger.MiniDebugger('Logger')
        self.debugger.flush() # Flush log.
        self.debugger.log('Starting Logger...')
        self.utils = miniutil.MiniUtil()
        self.config = miniconfig.MiniConfig()
        self.run()


    # Remove pid file on exit.
    def __cleanup(self):
        # Reset led.
        if not self.DISABLE_LEDS:
            self.utils.set_plug_led_blue() 


    # Refresh the configuration data.
    def __refresh_config(self):
        self.config.refresh()


    # Main logger loops.
    def run(self):
        print('===================')
        print('Starting MiniLogger...')
        print('===================')

        # Set the sheevaplug led to flashing, change when we start logging.
        if not self.DISABLE_LEDS:
            self.utils.set_plug_led_heartbeat() 

        # Ensure something is set for directory.
        # The directory is validated here instead as well as the writer as 
        # there is little point logging data if there is no where 
        # to write it to.
        if self.config.get('log_dir') is None:
            self.debugger.log('Error: Invalid configuration data, exiting.')
            self.debugger.dump()
            sys.exit(1)

        self.log_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.config.get('log_dir'))

        # Validate as directory.
        self.utils.validate_dir(self.log_dir, self.debugger, 
                'Could not read or create log dir.')

        # Stop and wait here if the settings indicate logging is disabled.
        if self.config.get('logging_enabled') == '0':
            self.__disabled_waiter()

        # Now look for device, blocks here until seismometer is found.
        self.__find_device_and_connect()

        # Everythings good. Set the sheevaplug led to green, 
        # change to heartbeat on disconnect.
        if not self.DISABLE_LEDS:
            self.utils.set_plug_led_green() 

        # How many samples do we get in two minutes?
        two_min_samples = self.device.DEVICE_RATE * 120
        counter = 0

        # Begin logging.
        self.debugger.log('Commencing Logging...')
        print('Commencing Logging...')

        reconnect = False

        # Main loop, read data, queue it, refresh config every so often.
        while True:
            counter = counter + 1
            data = self.device.readline()
            time = UTCDateTime()
            # A return value of False indicates failure, try reconnecting.
            # The device can return zero, so test type.
            if type(data) == type(False):
                reconnect = True
                #Indicate an interruption to the writer
                to_q = [self.INTERRUPT_VALUE, time]
            else:
                to_q = [data, time]
            # Push this buffer into the queue for processing.
            # This is set to block on a full queue
            # in practice this shouldn't happen unless
            # something goes wrong at the writer.
            if self.q.full() == True:
                self.debugger.log("""Write queue is full, logger is waiting 
                        for it to clear.""") 
            self.q.put(to_q, True)
            # If needed, reconnect.
            if reconnect:
                self.__reconnect_to_device()
                reconnect = False
            # Refresh config after two minutes of sampling.
            if counter > two_min_samples:
                self.__refresh_config()
                counter = 0
                if self.config.get('logging_enabled') == '0':
                    self.__disabled_waiter()


    # Enter this function if logging is disabled, waiting until the setting
    # is changed by the user. Sleeps and checks every 30 secs.
    # Sends an interrupt to writer so it ends the current file.
    def __disabled_waiter():
        self.debugger.log('Logging disabled, see settings to restart.') 
        to_q = [self.INTERRUPT_VALUE, UTCDateTime()]
        self.q.put(to_q, True)
        while self.config.get('logging_enabled') == '0':
            self.sleep(30)
            self.__refresh_config()
        self.debugger.log('Logging recommencing.') 


    # Attempt to connect to a device, slows down the loop checking
    # after 20 attempts with a larger delay to reduce pointless 
    # work being done.
    def __find_device_and_connect(self):
        counter = 0
        slow_mode = False
        self.debugger.log('Looking for device.');
        self.device = minisepdevice.MiniSepDevice(self.debugger)
        if self.device.find_device() == False:
            self.debugger.log('Still searching...');
            while self.device.find_device() == False:
                if counter < 20:
                    counter = counter + 1
                    time.sleep(1)
                elif slow_mode == False:
                    self.debugger.log('Entering slow mode after 20 attempts.')
                    slow_mode = True
                    time.sleep(10)
                else:    
                    time.sleep(10)
        self.debugger.log('Device connected successfully.');
        # Set plug led to green for feedback.
        if not self.DISABLE_LEDS:
            self.utils.set_plug_led_green() 


    # Close any existing connection and try to reestablish.
    def __reconnect_to_device(self):
        self.device.disconnect()
        self.debugger.log('Disconnected from device.') 
        # Set plug led to flashing for feedback.
        if not self.DISABLE_LEDS:
            self.utils.set_plug_led_heartbeat()
        self.__find_device_and_connect()
