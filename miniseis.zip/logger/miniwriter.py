# logger/miniwriter.py
# Jon Gilbert
# Last updated: 08/03/2011
# Takes buffer objects from the logger via a queue
# then creates an output file based on its contents.

# Local imports.
from config import miniconfig
from debugger import minidebugger
from logger import minilogger, minibuffer
from devices import minisepdevice
from tools import miniutil
from external import lockfile
# Library imports.
from obspy.core import read, Trace, Stream, UTCDateTime
from multiprocessing import Queue
from time import gmtime, strftime
import datetime
import os
import sys
import numpy
import atexit
import struct
import shutil

class MiniWriter:


    LOG_FILE_NAME_FORMAT = '%Y%m%d_%H%M%S.mseed'
    SAMPLES_PER_FILE = 1800
    AS_BUFFER_SIZE = 512


    # Note the queue arg.
    def __init__(self, q):
        atexit.register(self.__cleanup)
        # Setup and enter run().
        self.debugger = minidebugger.MiniDebugger('Writer')
        self.debugger.log('Starting Writer...')
        self.q = q
        self.config = miniconfig.MiniConfig()
        self.utils = miniutil.MiniUtil()
        self.log_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.config.get('log_dir'))
        self.amaseis_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.config.get('amaseis_dir'))  
        self.as_enabled = self.config.get('amaseis_enabled')
        self.logging_enabled = self.config.get('logging_enabled')
        self.amaseis_file_verified = False
        self.last_amaseis_cleanup = 0
        self.run()


    # Cleanup on exit.
    def __cleanup(self):
        pass


    # Refresh the configuration data.
    def __refresh_config(self):
        self.config.refresh()
        self.log_dir = (os.path.dirname(os.path.realpath(sys.argv[0])) 
                + self.config.get('log_dir'))
        self.as_enabled = self.config.get('amaseis_enabled')
        self.logging_enabled = self.config.get('logging_enabled')

    # Main loop, wait for buffers to be available from
    # the queue, then write them to file.
    def run(self):
        # First buffer objects.
        self.mbuffer = minibuffer.MiniBuffer(self.SAMPLES_PER_FILE)
        self.abuffer = minibuffer.MiniBuffer(self.AS_BUFFER_SIZE)

        cur_hour = gmtime().tm_hour
        interrupt_time = None

        # Flags for first start timestamp.
        started_a = False
        started_m = False
        # Flag for amaseis switched on.
        as_live = False

        # Main loop.
        while True:
            # Check logging is enabled. Flush current data to file is it 
            # was on, and is now off.
            if self.logging_enabled == '0':
                if self.mbuffer.get_current_size() > 0:
                    self.__write_miniseed_file()
                    started_m = False
                if self.abuffer.get_current_size() > 0:    
                    self.abuffer = minibuffer.MiniBuffer(self.AS_BUFFER_SIZE)
                    self.started_a = False
                    as_live = False

            # Block here for values to arrive. When logging is disabled, 
            # and no data is incoming, the process will wait here.
            data, time = self.q.get(True)
            
            # Process miniseed data first.
            if started_m == False:
                self.mbuffer.set_start_time(time)
                self.mbuffer.set_filename(self.__log_file_setter(time))
                started_m = True

            # If we get an interrupt value, end the current buffer and write
            # out now. A new file can be started when the seismometer
            # becomes available again. 
            if data == minilogger.MiniLogger.INTERRUPT_VALUE: 
                if self.mbuffer.get_current_size() > 0:
                    self.__write_miniseed_file()
                    started_m = False
            
            # Attempt to add data, on failure (full buffer), write the file
            # and start a new buffer.
            elif self.mbuffer.add(data) == False:
                # First write the current buffer.
                self.__write_miniseed_file()
                # Start a new buffer with the current data.
                self.mbuffer = minibuffer.MiniBuffer(self.SAMPLES_PER_FILE)
                self.mbuffer.add(data)
                self.mbuffer.set_start_time(time)
                self.mbuffer.set_filename(self.__log_file_setter(time))
                # Refresh configuration after each write to file.
                self.__refresh_config()


            # Otherwise the sample WAS added to the buffer.
            else:
                # Always set the end time at this sample, in case it is
                # the last (due to an interrupt).
                self.mbuffer.set_end_time(time)

            # AmaSeis second (if enabled), otherwise process next sample.
            if self.as_enabled == '0':
                # Flush and reset any existing buffer in case it is 
                # switched off mid cycle.
                if as_live == True:
                    self.__write_amaseis_file()
                    self.abuffer = minibuffer.MiniBuffer(self.AS_BUFFER_SIZE)
                    self.started_a = False
                    as_live = False
                continue

            as_live = True

            if started_a == False:
                self.abuffer.set_start_time(time)
                started_a = True
            # After a previous interrupt pad out with zeros based on sample 
            # rate to cover elapsed time since last sample.
            adata = []
            if interrupt_time != None:
                diff = time.getTimeStamp() - interrupt_time.getTimeStamp()
                gap = int(diff * minisepdevice.MiniSepDevice.DEVICE_RATE)
                adata += gap*['0']
                interrupt_time = None
                
            # Push data into amaseis buffer, with interrupts registering
            # zeros. End a buffer after 512 samples (about 8kb) or hour change.
            if data == minilogger.MiniLogger.INTERRUPT_VALUE:
                adata.append('0') # Value the interrupt replaced.
                interrupt_time = time
            else:
                adata.append(data)

            # First check if the hour has changed.
            if gmtime().tm_hour != cur_hour:
                self.__write_amaseis_file()
                cur_hour = gmtime().tm_hour
                # Start new buffer.
                self.abuffer = minibuffer.MiniBuffer(self.AS_BUFFER_SIZE)
                self.abuffer.set_start_time(time)

            # Now loop through data (which may be a long list after an interrupt)
            # adding samples and writing if need be. Typically adata should
            # only contain 1 sample.
            for value in adata:
                # Attempt to add data, if full, write file and use new buffer.
                if self.abuffer.add(value) == False:
                    self.__write_amaseis_file()
                    self.abuffer = minibuffer.MiniBuffer(self.AS_BUFFER_SIZE)
                    self.abuffer.add(value)   
                    self.abuffer.set_start_time(time)
                    self.__amaseis_cleanup()

                    
    def __write_miniseed_file(self):
        # Check something is actually in the buffer.
        data = self.mbuffer.get_buffer()
        if not data:
            return

        # First convert to numpy character array.
        data = numpy.array(self.mbuffer.get_buffer())
        chan = self.config.get('channel_prefix').upper()
        comp = self.config.get('component').upper()
        chan = chan + comp

        # Fill header attributes. Endtime is read only (computed by library).
        stats = {'network': self.config.get('station_network').upper(), 
                'station': self.config.get('station_id').upper(), 
                'location': '00', 
                'channel': chan,
                'npts': len(data), 
                'sampling_rate': str(minisepdevice.MiniSepDevice.DEVICE_RATE),
                'mseed' : {'dataquality' : 'D'}, 
                'starttime': self.mbuffer.get_start_time()}
        st = Stream([Trace(data=data, header=stats)])

        # Place a lock on the file before proceeding, such that the sender
        # can't access it part way through the operation.
        try:
            lock = lockfile.FileLock(self.mbuffer.get_filename())
            lock.acquire(10)
        except lockfile.LockTimeout:
            lock.break_lock()
            lock.acquire()
        except:
            # Break lock before exit.
            lock.break_lock()
            self.debugger.log('Miniseed write locking failed: ' + 
                    self.mbuffer.get_filename())
            sys.exit(1)

        st.write(self.mbuffer.get_filename(), format = 'MSEED', 
                encoding = 'STEIM2', reclen = 4096) 

        self.debugger.log('File Complete - ' + 
                self.mbuffer.get_filename().split(os.sep).pop())

        # Release lock, force it if need be.
        if lock.is_locked():
            try:
                lock.release()
            except:
                lock.break_lock()


    # Write out data to an amaseis hour record.
    def __write_amaseis_file(self):
        time = self.abuffer.get_start_time()
        # Run this once after receiving first buffer.
        if self.amaseis_file_verified == False:
            self.__amaseis_verify_file(time)

        # Get the path to the current file.
        path = self.__amaseis_file_setter(time)
        # Pack data for binary write.
        data = self.abuffer.get_buffer()
        data = struct.pack('h' * len(data), *(int(v) for v in data))

        # Lock file.
        try:
            lock = lockfile.FileLock(path)
            lock.acquire(10)
        except lockfile.LockTimeout:
            lock.break_lock()
            lock.acquire()
        except:
            # Break lock before exit.
            lock.break_lock()
            self.debugger.log('Amaseis write locking failed: ' + path)
            sys.exit(1)

        # Write file.
        with open(path, 'ab') as f:
            f.write(data)

        # Release lock, force it if need be.
        if lock.is_locked():
            try:
                lock.release()
            except:
                lock.break_lock()


    # Removes amaseis logs files older than one year,
    # executes on startup and while running, once per day.
    def __amaseis_cleanup(self):
        time = gmtime()
        if self.last_amaseis_cleanup == time.tm_yday:
            return
        # Record day of the year for comparison next time.
        self.last_amaseis_cleanup = time.tm_yday   

        # First check years.
        last_year = False
        for y in os.listdir(self.amaseis_dir):
            try:
                y = int(y)
            except:
                pass
            else:
                path = self.amaseis_dir + os.sep + str(y)
                # If it is empty, just remove it.
                if not os.listdir(path):
                    try:
                        os.rmdir(path)
                    except:
                        self.debugger.log('Could not remove: ' + path)
                # Record that we have a dir for last year.
                elif y == (time.tm_year - 1):
                    last_year = y
                # Data two years or more old, remove it all.
                elif y < (time.tm_year - 1):
                    if os.path.isdir(path):
                        try:
                            shutil.rmtree(path)
                        except:
                            self.debugger.log('Could not remove: ' + path)

        # Check each month from last year.
        if last_year == False:
            return

        path = self.amaseis_dir + os.sep + str(last_year)
        cur_mon = False
        for m in os.listdir(path):
            try:
                m_int = int(m)
            except:
                pass
            else:
                path = self.amaseis_dir + os.sep + str(last_year)  + os.sep + m
                # If it is empty, just remove it.
                if not os.listdir(path):
                    try:
                        os.rmdir(path)
                    except:
                        self.debugger.log('Could not remove: ' + path)
                # Save current month, if it is not the first day.
                if m_int == time.tm_mon and time.tm_mday > 1:
                    cur_mon = m
                # Or just remove older months entirely.
                elif m_int < time.tm_mon:
                    if os.path.isdir(path):
                        try:
                            shutil.rmtree(path)
                        except:
                            pass

        # Finally check the days within the current month.
        # Leap years will be caught in the month block above on 1st March.
        path = (self.amaseis_dir + os.sep + str(last_year) + os.sep + 
                str(cur_mon))
        for d in os.listdir(path):
            try:
                d_int = int(d)
            except:
                pass
            else:
                # Remove any days less than todays value.
                if d_int < time.tm_mday:
                    path = (self.amaseis_dir + os.sep + str(last_year) 
                            + os.sep + str(cur_mon) + os.sep + d)
                    if os.path.isdir(path):
                        try:
                            shutil.rmtree(path)
                        except:
                            self.debugger.log('Could not remove: ' + path)

        # Write log.
        self.debugger.log('AmaSeis old file cleanup complete.')


    # Open file, read it and pad out with zeros as needed. 
    # This is required to cover time spent rebooting or at initial startup.
    def __amaseis_verify_file(self, time):
        # Get the path to the current file.
        path = self.__amaseis_file_setter(time)
        # Check it exists, create if not.
        if os.path.isfile(path) == False:
            with open(path, 'wb') as f:
                # Just close immediately.
                f.close()
        # Get the time elapsed since the start of the hour.
        elapsed = time.getTimeStamp() % 3600
        # Find the number of samples that should be in that space.
        samples = int(minisepdevice.MiniSepDevice.DEVICE_RATE * elapsed)
        # Each sample is 16 bits or 2 bytes.
        size = os.stat(path).st_size / 2
        if size < samples:
            missing = samples - size 
        else:
            # Return now if file is OK.
            return

        # Pack data
        data = [0] * missing
        data = struct.pack('h' * missing, *data)

        # Lock file.
        try:
            lock = lockfile.FileLock(path)
            lock.acquire(10)
        except lockfile.LockTimeout:
            lock.break_lock()
            lock.acquire()
        except:
            # Break lock before exit.
            lock.break_lock()
            self.debugger.log('Verification locking failed: ' + path)
            sys.exit(1)

        # Write file.
        with open(path, 'ab') as f:
            f.write(data)

        # Release lock, force it if need be.
        if lock.is_locked():
            try:
                lock.release()
            except:
                lock.break_lock()


    # Creates current log file name based on time.
    def __log_file_setter(self, time):
        time = time.utctimetuple()
        filename = strftime(self.LOG_FILE_NAME_FORMAT, time)
        path = (self.log_dir + os.sep + self.config.get('station_id') 
                + '_' + filename)
        return path


    # Returns path to current amaseis file name based on time.
    # Creates any required directories.
    def __amaseis_file_setter(self, time):
        t = time.utctimetuple()
        year = str(t.tm_year)
        month = str(t.tm_mon).zfill(2)
        day = str(t.tm_mday).zfill(2)
        hour = str(t.tm_hour).zfill(2)
        local_path = year + os.sep + month + os.sep + day
        path = self.amaseis_dir + os.sep + local_path
        if os.path.isdir(path) == False:
            try:
                os.makedirs(path)
            except:
                # If creating dirs fails, exit.
                self.debugger.log("""Cannot access amaseis directory, 
                        shutting down.""")
                sys.exit(1)
        p = path + os.sep + hour + '.' + self.config.get('component').upper()
        return p
