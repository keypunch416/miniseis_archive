# buffer.py
# Jon Gilbert
# Last updated: 18/12/2010
# Buffer for incoming data, holding filename and start/end times.

#Library imports.
from obspy.core import UTCDateTime

class MiniBuffer:


    STRING_SEP = ', '
    DEFAULT_SIZE = 2048


    # Setup.
    def __init__(self, max_size = DEFAULT_SIZE):
        try:
            max_size = abs(int(max_size))
        except Exception:
            max_size = self.DEFAULT_SIZE
        self.values = []
        self.start_time = 0
        self.end_time = 0
        self.max_size = max_size
        self.filename = ''


    # Add a single value to the buffer,
    # return true on success
    # or false on a full buffer.
    def add(self, value):
        # Make sure everything sent here is an int
        try:
            value = int(value)
        except IOError:
            # Just ignore a bad value and continue. TODO: better way?
            return True
        # Store it if there is space
        if len(self.values) < self.max_size:
            self.values.append(value)
            return True
        # Otherwise return false
        return False


    # Set the start time to the UTCDateTime object
    def set_start_time(self, time):
        self.start_time = time


    # Set the end time to the UTCDateTime object
    def set_end_time(self, time):
        self.end_time = time


    # Specify the maximum size of the buffer, 
    # such that no more data can be added.
    # Returns true on success, false otherwise
    def set_max_size(self, size):
        try:
            size = abs(int(size))
        except Exception:
            size = self.DEFAULT_SIZE
        if size < 1:
            return False
        self.max_size = size
        return True


    # Sets the filename for this buffer.
    def set_filename(self, filename):
        self.filename = filename


    # Getters for data below.
    def get_buffer(self):
        return self.values
  

    # Convert list to string, line break seperated.
    def get_buffer_as_string(self):
        return self.STRING_SEP.join(self.values)


    def get_start_time(self):
        return self.start_time


    def get_end_time(self):
        return self.end_time


    def get_current_size(self):
        return len(self.values)


    def get_buffer_max_size(self):
        return self.max_size


    def get_filename(self):
        return self.filename
